# -*- coding: utf-8 -*-
# SoundInsight 在线 Demo（ModelScope 创空间版）
# 模型权重在启动时从 ModelScope 模型仓库自动下载（见 download_models 函数），
# 全部参数从 config.json 读取，无任何硬编码路径。
import json
import os
import sys

import requests

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import gradio as gr
import numpy as np
import pandas as pd
import torch
from transformers import (DistilBertForSequenceClassification,
                          DistilBertTokenizer)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import report_builder as rb  # noqa: E402
from text_utils import is_unsupported  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(HERE, "config.json"), encoding="utf-8") as f:
    CFG = json.load(f)

BIN_DIR = os.path.join(HERE, CFG.get("bin_model_dir", "sound_model"))
ML_DIR = os.path.join(HERE, CFG.get("multi_label_dir", "multi_label_model"))
MODEL_REPO_ID = CFG.get("model_repo_id", "")  # 用户建仓后填入
# 按多个入口顺序回退下载模型文件，并显式带 Revision 参数，
# 提高不同运行环境下的可用性。
MODELSCOPE_HOSTS = ["www.modelscope.cn", "modelscope.cn"]
MAX_LEN = int(CFG.get("max_len", 128))

FILES_BIN = ["config.json", "tokenizer.json", "tokenizer_config.json",
             "threshold.json", "model.safetensors"]
FILES_ML = ["config.json", "tokenizer.json", "tokenizer_config.json",
            "issue_labels.json", "model.safetensors"]


def _get_file(repo, path, timeout=600):
    """按 域名×URL风格×Revision 组合回退下载；全部失败时异常里带 URL 与响应摘要。"""
    candidates = []
    for host in MODELSCOPE_HOSTS:
        for rev in ("master", ""):
            url = (f"https://{host}/api/v1/models/{repo}/repo"
                   f"?FilePath={path}"
                   + (f"&Revision={rev}" if rev else ""))
            candidates.append(url)
    for host in MODELSCOPE_HOSTS:
        candidates.append(
            f"https://{host}/models/{repo}/resolve/master/{path}")
    last = ""
    for url in candidates:
        try:
            r = requests.get(url, timeout=timeout, stream=True)
        except requests.RequestException as e:  # noqa: BLE001 - 记录后回退
            last = f"{url} -> {type(e).__name__}: {e}"
            continue
        if r.status_code == 200:
            return r
        last = f"{url} -> HTTP {r.status_code} {r.text[:200]}"
    raise RuntimeError(f"下载失败 {path}: {last}")


def download_models():
    """启动时从 ModelScope 模型仓库下载权重（已存在则跳过）。

    注意：仓库内文件路径是相对目录名（sound_model/config.json），
    不能把本地绝对路径拼进下载 URL。
    """
    if not MODEL_REPO_ID:
        raise RuntimeError("config.json 中未填写 model_repo_id，"
                           "请先在 ModelScope 建仓并填入")
    for rel, dname, files in [
            ("sound_model", BIN_DIR, FILES_BIN),
            ("multi_label_model", ML_DIR, FILES_ML)]:
        os.makedirs(dname, exist_ok=True)
        for fname in files:
            dst = os.path.join(dname, fname)
            if os.path.exists(dst) and os.path.getsize(dst) > 1000:
                continue
            r = _get_file(MODEL_REPO_ID, f"{rel}/{fname}")
            with open(dst, "wb") as fp:
                for chunk in r.iter_content(1 << 20):
                    fp.write(chunk)
            print(f"下载 {fname} -> {dname}", flush=True)


download_models()

device = torch.device("cpu")  # 创空间免费环境为 CPU
tok = DistilBertTokenizer.from_pretrained(BIN_DIR)
bin_model = DistilBertForSequenceClassification.from_pretrained(BIN_DIR)
bin_model.eval()
with open(os.path.join(BIN_DIR, "threshold.json"), encoding="utf-8") as f:
    THR = float(json.load(f)["threshold"])
ml_model = DistilBertForSequenceClassification.from_pretrained(ML_DIR)
ml_model.eval()
with open(os.path.join(ML_DIR, "issue_labels.json"), encoding="utf-8") as f:
    ISSUE_INFO = json.load(f)
print(f"模型加载完成 | threshold={THR:.4f}")


def single_predict(text):
    if not text or not text.strip():
        return "请输入英文评论"
    # 非英文显式拒绝（与 predict_core / 批量路径同规则；此前本路径缺失，红队指出后补）
    if is_unsupported(text):
        return ("**不支持的语种（非拉丁字母文本）**：本系统按英文训练，对中文/日文/韩文/西里尔等显式拒绝。\n"
                "该条未给出音质判定——批量路径会将其跳过并计数。"
                "（注：德文/法文/西文等**拉丁字母**语言不在检测范围内，其表现未经测试，见主文档附录 B 第 6 条）")
    enc = tok(text.strip(), padding=True, truncation=True,
              max_length=MAX_LEN, return_tensors="pt")
    with torch.no_grad():
        prob = float(torch.softmax(bin_model(**enc).logits, -1)[0, 1])
        issues = torch.sigmoid(ml_model(**enc).logits)[0].numpy()
    label = "音质负面" if prob >= THR else "音质正常"
    hit = [ISSUE_INFO["names"][k] for k in range(len(issues))
           if issues[k] >= 0.5]
    issue_text = "；".join(hit) if hit else "无明显问题类别"
    return (f"{label}（音质负面概率 {prob:.1%}）\n问题归因：{issue_text}\n"
            f"（概率未经校准，仅供排序参考）")


def batch_analyze(file_obj):
    """批量分析：输出与本地 Agent 同口径的完整六节报告（含优先级与行动建议）。"""
    if file_obj is None:
        return "请先上传 CSV 文件", None
    path = getattr(file_obj, "path", None) or getattr(file_obj, "name", None) \
        or str(file_obj)
    try:
        df = pd.read_csv(path, encoding="utf-8", keep_default_na=False)
    except Exception as e:  # noqa: BLE001 - 反馈给用户
        return f"读取失败：{e}", None
    text_col = next((c for c in ("text", "reviewText", "review")
                     if c in df.columns), df.columns[0])
    all_texts = df[text_col].astype(str).tolist()

    # 非英文评论显式跳过（与本地版同一实现）
    texts = [t for t in all_texts if not is_unsupported(t)]
    n_unsup = len(all_texts) - len(texts)
    if not texts:
        return "未找到可分析的英文评论（非英文评论已跳过）", None

    probs = []
    with torch.no_grad():
        for b in range(0, len(texts), 32):
            enc = tok(texts[b:b + 32], padding=True, truncation=True,
                      max_length=MAX_LEN, return_tensors="pt")
            probs.append(torch.softmax(bin_model(**enc).logits, -1)
                         [:, 1].numpy())
    probs = np.concatenate(probs)
    neg_idx = [i for i, p in enumerate(probs) if p >= THR]
    issue_names = ISSUE_INFO["names"]
    issue_counts = {name: 0 for name in issue_names}
    ml_by_idx = {}
    if neg_idx:
        neg_texts = [texts[i] for i in neg_idx]
        ml_out = []
        with torch.no_grad():
            for b in range(0, len(neg_texts), 32):
                enc = tok(neg_texts[b:b + 32], padding=True, truncation=True,
                          max_length=MAX_LEN, return_tensors="pt")
                ml_out.append(torch.sigmoid(ml_model(**enc).logits).numpy())
        ml_all = np.vstack(ml_out)
        ml_pred = (ml_all >= 0.5).astype(int)
        for k, name in enumerate(issue_names):
            issue_counts[name] = int(ml_pred[:, k].sum())
        ml_by_idx = {i: ml_all[k] for k, i in enumerate(neg_idx)}

    examples = []
    for i in sorted(neg_idx, key=lambda j: -probs[j])[:5]:
        ip = {}
        if i in ml_by_idx:
            ip = {name: float(ml_by_idx[i][k])
                  for k, name in enumerate(issue_names)}
        examples.append({"text": texts[i], "prob": float(probs[i]),
                         "issue_probs": ip})

    rating_col = next((c for c in ("rating", "overall", "score")
                       if c in df.columns), None)
    avg_rating = (float(pd.to_numeric(df[rating_col], errors="coerce").mean())
                  if rating_col else float("nan"))
    n_mid = int(((probs >= 0.5) & (probs < THR)).sum())

    report_text = rb.build_report(
        src_name=os.path.basename(path), n_total=len(all_texts),
        n_unsupported=n_unsup, n_valid=len(texts), n_neg=len(neg_idx),
        avg_rating=avg_rating, issue_counts=issue_counts, examples=examples,
        n_mid=n_mid, lang="zh")
    report_path = os.path.join(HERE, "batch_report.md")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report_text)
    return report_text, report_path


EDGE_CASES = [
    ("委婉表达", "评论在批评音质但用词缓和，不含负面关键词。",
     "Was expecting a deeper bass given the price point, but it is "
     "acceptable for casual listening.", "音质负面概率 95.4%",
     "模型对委婉差评识别存在挑战，当前召回率偏低"),
    ("中性比较", "评论以对比为主，同时提到优劣两面，难以二分。",
     "Not as loud as my previous pair, but the clarity is actually better.",
     "音质负面概率 0.1%", "模型倾向于保守判定，避免误报"),
    ("关键词误触", "命中音质关键词，但语义与音质缺陷无关。",
     "It sounds like a great deal, and shipping was fast.",
     "音质负面概率 0.1%", "LLM 复核已过滤大部分误报"),
    ("评分冲突", "评分与文字不一致，如五星但文字批评音质。",
     "Great product, though the bass is a little muddy.",
     "音质负面概率 98.1%", "以文字语义为准，评分仅作参考"),
    ("多语言", "非英文或中英混杂评论，当前模型未覆盖。",
     "La calidad del sonido es regular, esperaba más graves.",
     "音质负面概率 0.0%", "当前版本仅支持英文，多语言扩展为未来工作"),
    ("极短评论", "评论过短导致上下文不足。",
     "Meh.", "音质负面概率 0.0%", "短文本置信度低，建议人工复核"),
]


def edge_cases_md():
    lines = ["## 六类边界案例及模型表现", ""]
    for name, definition, sample, prob, note in EDGE_CASES:
        lines.append(f"### {name}")
        lines.append(f"定义：{definition}")
        lines.append(f"样例：{sample}")
        lines.append(f"预测：{prob}")
        lines.append(f"模型表现：{note}")
        lines.append("")
    lines.append("> 上述概率未经校准，仅供排序参考。")
    return "\n".join(lines)


EXAMPLES = [
    "The sound quality is terrible, the bass is muddy and there is "
    "constant static.",
    "Great battery life and very comfortable to wear.",
    "Sounds crackle and hiss constantly, completely unusable.",
]

with gr.Blocks(title="🔊 蓝牙耳机音质差评检测器") as demo:
    gr.Markdown("# 🔊 蓝牙耳机音质差评检测器")
    gr.Markdown("SoundInsight：音质差评自动识别 + 五类问题归因。"
                "项目地址：https://github.com/DaiYanQBZ95Doll/soundinsight")
    with gr.Tab("单条评论"):
        inp = gr.Textbox(label="英文评论", lines=4,
                         placeholder="Paste an English product review...")
        btn = gr.Button("检测")
        out = gr.Textbox(label="判定结果")
        btn.click(single_predict, inputs=inp, outputs=out)
        gr.Examples(EXAMPLES, inputs=inp)
    with gr.Tab("批量分析"):
        fup = gr.File(label="上传评论 CSV（含 text 列）")
        btn2 = gr.Button("生成洞察报告")
        out2 = gr.Textbox(label="报告摘要")
        dload = gr.File(label="下载报告文件")
        btn2.click(batch_analyze, inputs=fup, outputs=[out2, dload])
    with gr.Tab("边界案例"):
        gr.Markdown(edge_cases_md())

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=7860)
