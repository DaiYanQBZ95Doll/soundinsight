# -*- coding: utf-8 -*-
# predict_core.py — SoundInsight 共享推理核心（soundinsight_agent / api_server /
# benchmark 共用同一套加载与推理路径，保证口径一致）。
#
# E7 非英文显式拒绝：评论中非拉丁字母占比 > 30% 或全无拉丁字母时，
# 返回 is_unsupported=True 且不给出音质判定（静默漏报风险修复）。
import json
import os
import re
import sys

import numpy as np
import torch
from transformers import (DistilBertForSequenceClassification,
                          DistilBertTokenizer)

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(HERE, "config.json"), encoding="utf-8") as f:
    CFG = json.load(f)
BIN_MODEL = os.path.join(HERE, CFG["bin_model_dir"])
ML_MODEL = os.path.join(HERE, CFG["multi_label_dir"])
THR_FILE = os.path.join(HERE, CFG["threshold_file"])
ISSUE_FILE = os.path.join(HERE, CFG["issue_labels_file"])
BATCH = int(CFG["batch_size"])
MAX_LEN = int(CFG["max_len"])

# 语种判定（非英文显式拒绝）的实现唯一放在 text_utils.py
from text_utils import is_unsupported  # noqa: E402,F401
from audio_gate import gate  # noqa: E402  闸门定义唯一来源（R32）

GATE_PREFILTER = bool(CFG.get("gate_prefilter", False))
TIER_HIGH = float(CFG.get("tier_high", 0.9))
TIER_LOW = float(CFG.get("tier_low", 0.5))
SCOPE_FILTER = bool(CFG.get("scope_filter", False))
SCOPE_DIR = os.path.join(HERE, CFG.get("scope_model_dir", "v2/model_scope"))
SCOPE_CATS = ["headphone", "earbud", "headset", "speaker", "soundbar", "other_audio",
              "cable", "non_audio", "unclear"]
_scope_cache = {}


def _scope_category(texts):
    """本地品类模型（零 API）。缺失模型时返回 None 列表，不阻断主流程。"""
    if not os.path.isdir(SCOPE_DIR):
        return [None] * len(texts)
    if not _scope_cache:
        from transformers import DistilBertForSequenceClassification as _C
        st = load()
        _scope_cache["tok"] = st["tok"]
        _scope_cache["model"] = _C.from_pretrained(SCOPE_DIR).to(st["device"]).eval()
        _scope_cache["device"] = st["device"]
    tok, mdl, dev = _scope_cache["tok"], _scope_cache["model"], _scope_cache["device"]
    import torch as _t
    out = []
    with _t.no_grad():
        for b in range(0, len(texts), 64):
            e = tok(texts[b:b + 64], padding=True, truncation=True, max_length=192,
                    return_tensors="pt")
            e = {k: v.to(dev) for k, v in e.items()}
            out += [SCOPE_CATS[k] for k in mdl(**e).logits.argmax(-1).cpu().tolist()]
    return out


_state = None


def load(device: str = None):
    """加载模型（进程内缓存）。device: 'cuda'|'cpu'|None(自动)。"""
    global _state
    if _state is not None and (device is None or _state["device_name"] == device):
        return _state
    dev = (device if device in ("cuda", "cpu")
           else ("cuda" if torch.cuda.is_available() else "cpu"))
    tok = DistilBertTokenizer.from_pretrained(BIN_MODEL)
    bin_model = DistilBertForSequenceClassification.from_pretrained(
        BIN_MODEL).to(dev)
    bin_model.eval()
    with open(THR_FILE, encoding="utf-8") as f:
        thr = float(json.load(f)["threshold"])
    ml_model = DistilBertForSequenceClassification.from_pretrained(
        ML_MODEL).to(dev)
    ml_model.eval()
    with open(ISSUE_FILE, encoding="utf-8") as f:
        issue_info = json.load(f)
    _state = {"device": torch.device(dev), "device_name": dev,
              "tok": tok, "bin": bin_model, "thr": thr,
              "ml": ml_model, "issues": issue_info}
    return _state


def _bin_probs(model, tok, texts, device):
    probs = []
    with torch.no_grad():
        for b in range(0, len(texts), BATCH):
            enc = tok(texts[b:b + BATCH], padding=True, truncation=True,
                      max_length=MAX_LEN, return_tensors="pt")
            enc = {k: v.to(device) for k, v in enc.items()}
            probs.append(torch.softmax(model(**enc).logits, -1)
                         [:, 1].cpu().numpy())
    return np.concatenate(probs)


def _ml_sigmoid(model, tok, texts, device):
    out = []
    with torch.no_grad():
        for b in range(0, len(texts), BATCH):
            enc = tok(texts[b:b + BATCH], padding=True, truncation=True,
                      max_length=MAX_LEN, return_tensors="pt")
            enc = {k: v.to(device) for k, v in enc.items()}
            out.append(torch.sigmoid(model(**enc).logits).cpu().numpy())
    return np.vstack(out)


def predict_batch(texts, device: str = None):
    """批量推理。返回与输入等长的结果列表，每项为 dict：
    {text, is_unsupported, prob, pred, issues, issue_probs}
    不支持/空文本：prob=None, pred=None, issues=[]。
    闸门预筛开启且未命中：is_out_of_scope=True, prob=None, pred=None（明确"未判定"）。
    每项均含 gate_matched 供报告与界面披露。"""
    st = load(device)
    texts = [str(t) for t in texts]
    flags = [is_unsupported(t) for t in texts]
    gates = [gate(t) for t in texts]
    # 预筛开启时：未命中闸门者不进入模型（既不判正也不判负，明确标注"未判定"）
    supported = [t for t, f, g in zip(texts, flags, gates)
                 if not f and (g or not GATE_PREFILTER)]
    probs_map, ml_map = {}, {}
    if supported:
        p = _bin_probs(st["bin"], st["tok"], supported, st["device"])
        probs_map = {t: float(v) for t, v in zip(supported, p)}
        pos_texts = [t for t, v in zip(supported, p) if v >= st["thr"]]
        if pos_texts:
            ml = _ml_sigmoid(st["ml"], st["tok"], pos_texts, st["device"])
            names = st["issues"]["names"]
            ml_map = {t: {"issues": [names[k] for k in range(len(names))
                                     if ml[i, k] >= 0.5],
                          "issue_probs": {names[k]: float(ml[i, k])
                                          for k in range(len(names))}}
                      for i, t in enumerate(pos_texts)}
    scope_cats = _scope_category(texts)
    results = []
    for t, f, g, sc in zip(texts, flags, gates, scope_cats):
        if f:
            results.append({"text": t, "is_unsupported": True, "is_out_of_scope": False,
                            "gate_matched": g, "prob": None,
                            "pred": None, "issues": [], "issue_probs": {}})
            continue
        if SCOPE_FILTER and sc in ("speaker", "soundbar", "other_audio", "cable",
                                   "non_audio"):   # 只排除**明确非耳机**；unclear 保留（否则丢真阳）
            results.append({"text": t, "is_unsupported": False, "is_out_of_scope": True,
                            "gate_matched": g, "scope_category": sc, "prob": None,
                            "pred": None, "tier": "excluded_nonheadphone",
                            "issues": [], "issue_probs": {}})
            continue
        if GATE_PREFILTER and not g:
            results.append({"text": t, "is_unsupported": False, "is_out_of_scope": True,
                            "gate_matched": False, "prob": None,
                            "pred": None, "issues": [], "issue_probs": {}})
            continue
        prob = probs_map[t]
        pred = int(prob >= st["thr"])
        if pred:
            issues = ml_map.get(t, {}).get("issues", [])
            issue_probs = ml_map.get(t, {}).get("issue_probs", {})
        else:
            issues, issue_probs = [], {}
        tier = ("priority" if prob >= TIER_HIGH else
                ("review" if prob >= TIER_LOW else "below_threshold"))
        results.append({"text": t, "is_unsupported": False, "is_out_of_scope": False,
                        "gate_matched": g, "scope_category": sc, "prob": prob, "tier": tier,
                        "pred": pred, "issues": issues,
                        "issue_probs": issue_probs})
    return results


def predict_single(text, device: str = None):
    """单条推理，返回一个结果 dict。"""
    return predict_batch([text], device)[0]
