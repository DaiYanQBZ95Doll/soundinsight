# -*- coding: utf-8 -*-
# report_builder.py —— SoundInsight 洞察报告生成共享模块
#
# 三个入口共用同一套口径，避免"命令行 Agent 有完整报告、Demo 只有摘要"的不一致：
#   - soundinsight_agent.py（命令行一键 Agent，md/excel、zh/en）
#   - demo_sound_v2.py（本地 Gradio Demo 批量分析页）
#   - deployment/app.py（ModelScope 创空间在线 Demo）
#
# 报告结构（六节）：总体概况 / 问题分布 / 典型案例 / 行动建议 / 验证指标 / 附注
import math
from datetime import datetime

ISSUE_PRIORITY_DOC = ("优先级规则：占比前三且数量≥总差评数 10% 的类别为高；"
                      "其余有正数的为中；数量为 0 的为低。")


def rank_issues(issue_counts: dict):
    """按数量降序排列并给出优先级。返回 (ranked, priority)。"""
    total = sum(issue_counts.values())
    ranked = sorted(issue_counts.items(), key=lambda x: -x[1])
    priority = {}
    for rank, (name, cnt) in enumerate(ranked):
        if cnt > 0 and rank < 3 and total > 0 and cnt >= max(total, 1) * 0.1:
            priority[name] = "高"
        elif cnt > 0:
            priority[name] = "中"
        else:
            priority[name] = "低"
    return ranked, priority


def verdict(rate: float, lang: str = "zh") -> str:
    """按差评率给出结论一句话。"""
    if lang == "en":
        if rate >= 0.03:
            return ("Severe: sound-quality complaint rate is significantly "
                    "elevated; investigate immediately")
        if rate >= 0.015:
            return "Elevated: monitor closely and start remediation"
        return "Healthy: sound-quality reputation is at a normal level"
    if rate >= 0.03:
        return "严重，音质差评率显著偏高，建议立即排查"
    if rate >= 0.015:
        return "偏高，建议关注并启动整改"
    return "正常，音质口碑处于健康水平"


def cost_line(n: int, lang: str = "zh") -> str:
    """成本对照行（本地推理 0 API 费用 vs LLM 实测单价）。"""
    est = n / 1000 * 0.03
    if lang == "en":
        return (f"- Cost: local inference = 0 API fee; same batch via LLM "
                f"(deepseek-chat, measured ~$0.03/1000) ≈ ${est:.2f} "
                f"(see llm_baseline.md).")
    return (f"- 成本对照：本地推理 0 API 费用；同等 {n} 条若调用 LLM"
            # 注意：$0.03/千条＝二元短文本实测；$0.1378/千条＝五类归因长文本重 prompt 实测

            f"（deepseek-chat，实测约 $0.03/1000 条，见 llm_baseline.md）"
            f"约 ${est:.2f}。")


def _example_lines(examples, lang: str = "zh", top_text: int = 120):
    """典型案例：概率 + 原文 + 五类归因概率（模型本就计算了五类概率）。"""
    lines = []
    for i, ex in enumerate(examples, 1):
        text = str(ex.get("text", "")).replace("\n", " ")[:top_text]
        prob = ex.get("prob")
        head = f"{i}. （{prob:.1%}）{text}" if prob is not None else f"{i}. {text}"
        lines.append(head)
        probs = ex.get("issue_probs") or {}
        if probs:
            ranked = sorted(probs.items(), key=lambda x: -x[1])[:3]
            detail = "、".join(f"{k} {v:.2f}" for k, v in ranked)
            label = "归因概率" if lang == "zh" else "issue probs"
            lines.append(f"   {label}：{detail}")
    return lines


def confidence_action_lines(n_high: int, n_mid: int, n_low: int, lang: str) -> list:
    """W17：置信度三档 → 建议动作（统一口径，报告与主文档共用同一张表）。

    阈值口径：与冻结模型 `sound_model/threshold.json` 的调优档一致（0.9744，v1 冻结口径）；
    报告正文的中置信提示使用同一区间，改阈值时须同步这三处。
    """
    tuned_thr = 0.9744  # [v1] 冻结模型调优档
    if lang == "en":
        return [
            "",
            "## Confidence tiers and recommended actions",
            "| Tier | Probability band | Meaning | Recommended action |",
            "|---|---|---|---|",
            f"| High | >= {tuned_thr} (tuned) | High-confidence sound-quality complaint | "
            f"Send to engineering/QC review ({n_high} reviews) |",
            f"| Mid | 0.5 - {tuned_thr} | Suspected negative, evidence insufficient | "
            f"Manual spot-check first ({n_mid} reviews) |",
            f"| Low | < 0.5 | Treated as normal | Track in trend only, not in issue "
            f"distribution ({n_low} reviews) |",
        ]
    return [
        "",
        "## 六、置信度档位与建议动作",
        "| 档位 | 概率区间 | 含义 | 建议动作 |",
        "|---|---|---|---|",
        f"| 高 | ≥ {tuned_thr}（调优档） | 高置信音质差评 | 直接进入整改/研发评审"
        f"（{n_high} 条） |",
        f"| 中 | 0.5 – {tuned_thr} | 疑似负面，证据不足 | 先做小规模人工抽查"
        f"（{n_mid} 条） |",
        f"| 低 | < 0.5 | 判为正常 | 仅计入趋势观察，不进入问题分布（{n_low} 条） |",
    ]


def build_report(*, src_name: str, n_total: int, n_unsupported: int,
                 n_valid: int, n_neg: int, avg_rating: float,
                 issue_counts: dict, examples=None, n_mid: int = 0,
                 n_out_of_scope: int = 0, n_priority: int = 0, n_review: int = 0,
                 type_counts: dict = None, vague_counts: dict = None,
                 lang: str = "zh", generated_at: str = None) -> str:
    """生成六节洞察报告（Markdown 文本）。所有数字由调用方传入，不在此处编造。

    `n_out_of_scope`：因**不含音频词汇**而未判定的条数（闸门预筛开启时）。
    该计数与判定条数**必须同屏**——产品只对含音频词汇的评论判定，这是实测口径（附录 C 第 13 条）。"""
    examples = examples or []
    rate = (n_neg / n_valid) if n_valid else 0.0
    scope_rate = (n_out_of_scope / n_total) if n_total else 0.0
    ranked, priority = rank_issues(issue_counts)
    total_issue = sum(issue_counts.values())
    stamp = generated_at or datetime.now().strftime("%Y-%m-%d %H:%M")
    rating_known = not (isinstance(avg_rating, float) and math.isnan(avg_rating))

    if lang == "en":
        lines = ["# SoundInsight Sound Quality Report", "", "## 1. Overview",
                 f"Source: {src_name}", f"Generated: {stamp}",
                 f"Total reviews: {n_total} ({n_unsupported} non-English skipped)",
                 f"**Not assessed (no audio vocabulary): {n_out_of_scope} ({scope_rate:.1%})** — this tool assesses only reviews mentioning sound; "
                 "the rest are reported as not assessed, not as negatives.",
                 f"Valid reviews: {n_valid}",
                 f"Sound-quality negatives: {n_neg} ({rate:.2%})"]
        if rating_known:
            lines.append(f"Average rating: {avg_rating:.2f}")
        lines.append(f"Verdict: {verdict(rate, 'en')}")
        lines += ["", "## 2. Issue Breakdown",
                  "| Issue | Count | Share | Priority |",
                  "|-------|-------|-------|----------|"]
        for name, cnt in ranked:
            pr = {"高": "High", "中": "Medium", "低": "Low"}[priority[name]]
            lines.append(f"| {name} | {cnt} | "
                         f"{cnt / max(total_issue, 1):.1%} | {pr} |")
        lines += ["", "## 3. Typical Cases"]
        lines += _example_lines(examples, "en") or ["No negative detected."]
        lines += ["", "## 4. Actions"]
        highs = [n for n, _ in ranked if priority[n] == "高"]
        if highs:
            for name in highs:
                lines.append(f"- Urgent ({name} | tier: high): check related hardware/QC or "
                             f"listing channels to reduce this complaint type.")
        else:
            lines.append("No concentrated issue detected; keep current QC.")
        lines += ["", "## 5. Verification"]
        lines.append("Re-run this analysis in 2-4 weeks and track the "
                     "same-scope complaint-rate change.")
        if n_mid:
            lines.append(f"- {n_mid} review(s) fall in the mid-confidence "
                         f"band (prob 0.5-0.9744): treated as normal but "
                         f"flagged for manual review.")
        lines += confidence_action_lines(n_neg, n_mid, n_valid - n_neg - n_mid, "en")
        lines += ["", "## 7. Notes",
                  "Auto-generated by SoundInsight (DistilBERT fine-tune, "
                  "human-annotated precision 75-78% / recall 68.3% (46-100%), 5-class "
                 "attribution macro-F1 0.44-0.52). "
                  "Edge cases carry error; verify key decisions manually.",
                  "Probabilities are uncalibrated, for ranking only "
                  "(see calibration_eval.md).", cost_line(n_valid, "en")]
        return "\n".join(lines)

    # 中文版
    lines = ["# SoundInsight 音质洞察报告", "", "## 一、总体概况",
             f"分析对象：{src_name}",
             f"分析时间：{stamp}",
             f"评论总数：{n_total} 条（其中非英文 {n_unsupported} 条已跳过）",
             f"**未判定（不含音频词汇）：{n_out_of_scope} 条（占比 {scope_rate:.2%}）**——"
             "本工具**只对提到声音的评论判定**；其余按「未判定」计，**不计入差评也不计入正常**。",
             f"**档位**：优先处理档 **{n_priority}** 条（**人工盲判 P 75–78%、召回 68%**（46–100%），两张独立样本；同条目捕获 39/41 真阳 vs v2 26/41，"
             f"见登记表 X-25～X-28）｜"
             f"待复核档 **{n_review}** 条｜范围外档 **{n_out_of_scope}** 条"
             "——档位名后的实测数字来自**人工盲判验收**（100 条分层样本），**引用时不得省略**。",
             "⚠️ **未判定 ≠ 正常**：范围外档只是我们未评估，不代表该评论没有问题。",
             "**两条线不是一条线**：**分诊档 0.95**（优先处理档的下界，用于分流人工）与"
             "**判定线 0.9744**（写进 threshold.json 的判正阈值，用于「是不是音质差评」的结论）——"
             "0.95–0.9744 之间的评论会出现在优先处理档、但**不计入音质差评数**；"
             "两条线的口径来源不同（前者＝人工验收的分档，后者＝v1 冻结世代的调优档），引用时勿混。",
             f"有效评论：{n_valid} 条",
             f"音质差评数：{n_neg} 条（占比 {rate:.2%}）"]
    if rating_known:
        lines.append(f"平均评分：{avg_rating:.2f}")
    lines.append(f"结论一句话：{verdict(rate)}")
    if type_counts:
        lines += ["", "## 二之二、非音质差评的类型分布（本地模型，初步）",
                  "｜".join(f"{k} {v}" for k, v in list(type_counts.items())[:10]),
                  "⚠️ 类型由**本地模型**给出（训练自 LLM 标签，**非精度最优**），用于分诊；未经人工校准前不得作为结论引用。"]
    if vague_counts:
        lines += ["", "## 二之三、不可归因原因（提到声音但说不清）",
              "⚠️ 与上一节同源：**本地模型、训练自 LLM 标签、未经人工校准**，"
              "仅作分诊线索，不得作为结论引用。",
                  "｜".join(f"{k} {v}" for k, v in list(vague_counts.items())[:8])]
    lines += ["", "## 二、问题分布",
              "| 问题类别 | 数量 | 占比 | 优先级 |",
              "|---------|------|------|--------|"]
    for name, cnt in ranked:
        lines.append(f"| {name} | {cnt} | "
                     f"{cnt / max(total_issue, 1):.1%} | {priority[name]} |")
    lines += ["", "## 三、典型案例"]
    lines += _example_lines(examples, "zh") or ["未检测到音质负面评论。"]
    lines += ["", "## 四、行动建议"]
    highs = [n for n, _ in ranked if priority[n] == "高"]
    if highs:
        for name in highs:
            obj = "生产/质检" if name in ("杂音", "低音") else "客服/详情页"
            lines.append(f"- 紧急（{name}｜置信档：高）：建议检查 {obj} 环节，"
                         f"预期降低该类差评率。")
    else:
        lines.append("未检测到集中性音质问题，建议维持当前品控。")
    lines += ["", "## 五、验证指标",
              "建议复评周期：2-4 周后重新运行批量分析，追踪同口径差评率变化。"]
    if n_mid:
        lines.append(f"- 中置信提示：有 {n_mid} 条评论概率落在 0.5-0.9744 区间，"
                     f"当前判为正常但建议人工抽查（疑似负面）。")
    lines += confidence_action_lines(n_neg, n_mid, n_valid - n_neg - n_mid, "zh")
    lines += ["", "## 七、附注",
              "本报告由 SoundInsight 自动生成，判定基于 DistilBERT "
              "微调模型（**判别器世代**；人工盲判口径 P 75–78%、召回 68.3%（46–100%），"
             "两张独立样本各 50 条；LLM 标签口径见附录 C 第 16 条）与五类多标签归因模型（人工口径宏 F1 0.44–0.52），"
              "边界案例存在一定误差，关键决策建议结合人工抽查。",
              "模型输出概率未经校准，仅供排序参考（见 calibration_eval.md）。",
              cost_line(n_valid, "zh")]
    return "\n".join(lines)
