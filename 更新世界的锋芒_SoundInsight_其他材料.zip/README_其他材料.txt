# SoundInsight 其他材料说明

本包为补充材料，供评委核查"数字是否可复现、结论是否可验证"。所有数字的权威源是
results_summary.md（冻结口径）；不同口径（冻结口径 / 1000 条子集口径 / 工程数字）
在报告中均已显式标注，不可混用。

## 一、验证报告
- llm_baseline.md：跨 LLM 对照实验（deepseek-chat、qwen3.7-plus 三设置；含循环性红利声明）
- length_bucket_eval.md：按 tokenizer 长度分桶（>128 token 截断桶 F1 0.565）
- edge_case_benchmark.md：六类边界场景定向探针
- calibration_eval.md：十箱 ECE 与过度自信证据
- error_taxonomy.md：FP/FN 错误分类学 + 标注噪声人工终审（15/16 → 9.1%）
- throughput_eval.md：GPU/CPU 吞吐实测
- stats_validation.md / ablation_summary.md / significance_test.md / confidence_tiered.md：
  统计验证、消融、显著性检验、置信度分层
- docs/dataset_audit.md / docs/year_split_output.txt：数据集字段考古与年份分桶脚本输出原文
- docs/drift_plan.md：数据漂移监控方案

## 二、审计与验收
- number_audit.md：数字一致性审计结果（含官方模板格式对照节）
- check_doc_numbers.py：审计脚本本体（可一键复跑：python check_doc_numbers.py）
- deploy_check.py / batch_check.py：在线 Demo 自动验收脚本（单条推理 + 批量上传）

## 三、人工复核原始表
- human_review_50.csv：标注人工抽查 50 条（通过率 78%）
- human_review_conf30.csv：中置信 8 条人工复核（3/8 通过 → 全部剔除）
- human_review_noise16.csv：标注噪声 16 条人工终审（15/16 确认）

## 四、图表
架构图、学习曲线、PR 曲线、混淆矩阵、可靠性曲线、月度趋势图、Demo 截图。

## 五、复算脚本
生成上述报告所需的推理与统计脚本（val_pred_dump.py、calibration_eval.py、
length_bucket_eval.py、edge_case_benchmark.py、throughput_bench.py、
llm_eval_metrics.py、llm_qwen_metrics.py、taxonomy_agg.py 等）。运行需本地模型权重
（从 ModelScope 公开仓库下载，见 MODEL_CARD.md）。

## 六、如实声明
本包不含任何虚构数据或虚构用户证言；本阶段未开展真实用户验证（已在
competition_v4.md 局限章节披露）。
