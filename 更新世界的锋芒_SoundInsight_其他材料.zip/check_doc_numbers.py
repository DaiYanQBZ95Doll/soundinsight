# -*- coding: utf-8 -*-
# 本脚本用于文档数字一致性审计：扫描指定文档，逐项核对红线数字，
# 检测口径违规，输出 number_audit.md。
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_MD = os.path.join(HERE, "number_audit.md")

# 数字 -> (允许的等价写法列表, 说明)
CORE_REQUIRED = [
    (r"0\.687", ["0.687", "0.6871", "68.7%"], "最终模型 F1"),
    (r"0\.6234", ["0.6234"], "5折CV平均F1"),
    (r"0\.024", ["0.024", "0.0240", "±0.024"], "CV标准差"),
    (r"0\.97", ["0.97", "0.9744"], "阈值"),
    (r"89\.6", ["89.6", "0.896"], "召回率"),
    (r"47\.9", ["47.9", "0.479"], "精确率"),
    (r"0\.497", ["0.497"], "SVM基线"),
    (r"0\.410", ["0.410", "0.41"], "LR基线"),
    (r"0\.025", ["0.025"], "dummy基线"),
    (r"0\.7191", ["0.7191"], "AUC-PR"),
    (r"0\.000932", ["0.000932", "0.0009"], "t检验p值"),
    (r"1257", ["1257"], "正例(实验口径)"),
    (r"78%", ["78%"], "人工抽查精度"),
    (r"41\.5%", ["41.5%"], "三星漏检率"),
    (r"51\.8%", ["51.8%"], "弱标注精度"),
]

CORE_FORBIDDEN = [
    (r"1297", "错误正例数1297"),
    (r"83\.7", "教师一致性出现在正文（仅允许方法说明/附录）"),
    (r"qwen3\.7-plus.*标注|标注.*qwen3\.7-plus", "已废弃的qwen标注复核claim"),
]

# Batch B 新数字：llm_baseline.md 必须包含（如实记录口径）
LLM_REQUIRED = [
    (r"0\.940", ["0.940", "94.0%"], "LLM零样本F1"),
    (r"0\.826", ["0.826"], "小模型子集F1"),
    (r"0\.873", ["0.873"], "LLM 5示例F1"),
    (r"0\.846", ["0.846"], "LLM复核模式F1"),
    (r"249,703", ["249,703", "249703"], "LLM实验tokens合计"),
    (r"0\.9044", ["0.9044", "0.904"], "LLM零样本召回"),
    (r"0\.7092", ["0.7092", "0.709"], "小模型子集召回"),
    (r"0\.971", ["0.971", "97.1%"], "LLM零样本Acc"),
    (r"2,560|2552", ["2,560", "2552", "2560"], "单批40条延迟实测"),
    (r"0\.9149", ["0.9149", "0.915"], "qwen零样本F1"),
    (r"490,747", ["490,747", "490747"], "qwen实验tokens合计"),
]

QNA_REQUIRED = [
    (r"0\.940", ["0.940", "94.0%"], "Q3/Q5/Q10 LLM零样本F1"),
    (r"0\.826", ["0.826"], "Q3 小模型子集F1"),
    (r"0\.873", ["0.873"], "Q10 5示例F1"),
    (r"0\.03", ["0.03", "$0.03"], "每1000条LLM成本"),
]

# 已废弃的旧claim，不得再出现在 Q&A 中
QNA_FORBIDDEN = [
    (r"0\.01/条", "已废弃的GPT-4单条$0.01成本claim"),
    (r"耗时 30 秒", "已废弃的未实测30秒claim"),
    (r"\$50", "已废弃的纯LLM标注$50成本claim"),
]

# Batch C/E 新文档数字
THROUGHPUT_REQUIRED = [
    (r"1\.763", ["1.763"], "GPU 1000条中位数(秒)"),
    (r"567\.1", ["567.1"], "GPU 吞吐(条/s)"),
    (r"28\.443", ["28.443"], "CPU 1000条中位数(秒)"),
    (r"35\.2", ["35.2", "35.6"], "CPU 吞吐(条/s)"),
]

CALIB_REQUIRED = [
    (r"0\.0122", ["0.0122"], "ECE十箱"),
    (r"0\.229", ["0.229"], "0.8-0.9箱实际正例率"),
    (r"0\.555", ["0.555"], "0.9-1.0箱实际正例率"),
]

ERRTAX_REQUIRED = [
    (r"FP=91", ["FP=91", "FP 91"], "误报数"),
    (r"FN=73", ["FN=73", "FN 73"], "漏报数"),
    (r"54\.9%", ["54.9%"], "FP其他问题占比"),
    (r"58\.9%", ["58.9%"], "FN委婉+双面占比"),
    (r"9\.1%", ["9.1%"], "标注噪声率(人工终审)"),
    (r"15/16", ["15/16"], "人工终审确认数"),
    (r"TP=179", ["TP=179"], "与冻结矩阵的调和说明"),
]

LENBUCKET_REQUIRED = [
    (r"0\.7080|0\.708", ["0.7080", "0.708"], "<=64 token F1"),
    (r"0\.7485|0\.749", ["0.7485", "0.749"], "65-128 token F1"),
    (r"0\.5649|0\.565", ["0.5649", "0.565"], ">128 token F1(截断桶)"),
    (r"3728", ["3728", "3,728"], ">128 token 评论数"),
    (r"tokenizer", ["tokenizer"], "token 口径声明"),
]

MODELCARD_REQUIRED = [
    (r"0\.0122", ["0.0122"], "ECE十箱"),
    (r"0\.9744", ["0.9744"], "阈值"),
    (r"9\.1%", ["9.1%"], "标注噪声率(人工终审)"),
    (r"1280", ["1280"], "当前工作集正例数"),
]

RESULTSSUMMARY_REQUIRED = [
    (r"0\.687", ["0.687", "0.6871"], "最终F1"),
    (r"TP=178", ["TP=178"], "GPU重跑矩阵调和行"),
    (r"FN=73", ["FN=73"], "GPU重跑FN"),
    (r"TP=179", ["TP=179"], "冻结矩阵"),
]

# 官方复赛模板（hackathon-复赛作品提交模板-天池版.docx）必备章节
TEMPLATE_SECTIONS = [
    "团队信息", "参赛信息", "业务价值与市场分析", "产品功能与使用说明",
    "技术架构及调用模型说明", "项目开发及阶段成果说明", "提交物清单",
    "附件命名规范", "注意事项",
]
TEMPLATE_FILES = ["competition_v4.md", "competition_v3.txt"]

GROUPS = [
    {"files": ["competition_v3.txt", "competition_v4.md", "README.md",
               "QWEN_HANDOFF.md", "ppt_text_dump.md"],
     "required": CORE_REQUIRED, "forbidden": CORE_FORBIDDEN, "check_1288": True},
    {"files": ["llm_baseline.md"],
     "required": LLM_REQUIRED, "forbidden": [], "check_1288": False},
    {"files": ["qna_preparation.md"],
     "required": QNA_REQUIRED, "forbidden": QNA_FORBIDDEN, "check_1288": False},
    {"files": ["throughput_eval.md"],
     "required": THROUGHPUT_REQUIRED, "forbidden": [], "check_1288": False},
    {"files": ["calibration_eval.md"],
     "required": CALIB_REQUIRED, "forbidden": [], "check_1288": False},
    {"files": ["error_taxonomy.md"],
     "required": ERRTAX_REQUIRED, "forbidden": [], "check_1288": False},
    {"files": ["length_bucket_eval.md"],
     "required": LENBUCKET_REQUIRED, "forbidden": [], "check_1288": False},
    {"files": ["MODEL_CARD.md"],
     "required": MODELCARD_REQUIRED, "forbidden": [], "check_1288": False},
    {"files": ["results_summary.md"],
     "required": RESULTSSUMMARY_REQUIRED, "forbidden": [], "check_1288": False},
]


def read_file(name):
    p = os.path.join(HERE, name)
    if not os.path.exists(p):
        return None, None
    with open(p, encoding="utf-8", errors="replace") as f:
        content = f.read()
    if name == "ppt_text_dump.md":
        # 只审计正文提取区，截断自动核对小节，避免自匹配假 FAIL
        marker = "## 自动核对"
        if marker in content:
            content = content.split(marker)[0]
    return content.splitlines(keepends=True), p


def audit_file(fname, required, forbidden, check_1288, out):
    lines, path = read_file(fname)
    if lines is None:
        out.append(f"## {fname}")
        out.append("- 文件不存在：SKIP（不判 FAIL）")
        out.append("")
        return
    out.append(f"## {fname}")
    # 必含数字
    for pattern, variants, desc in required:
        hits = []
        for i, line in enumerate(lines, 1):
            if re.search(pattern, line):
                hits.append(i)
        ok = "PASS" if hits else "FAIL"
        out.append(f"- [{ok}] {desc} ({pattern}): "
                   f"{'行 ' + ','.join(map(str, hits[:5])) if hits else '未出现'}")
    # 违禁检测
    for pattern, desc in forbidden:
        found = False
        for i, line in enumerate(lines, 1):
            m = re.search(pattern, line)
            if m:
                if desc.startswith("教师一致性") and \
                   re.search(r"方法|附录|蒸馏|不作为|可行性", line):
                    continue  # 方法说明语境，允许
                out.append(f"- [FAIL] {desc} 出现在行 {i}: "
                           f"{line.strip()[:80]}")
                found = True
                break
        if not found:
            out.append(f"- [PASS] 未发现 {desc}")
    # 正例口径：1288 出现时必须带口径说明
    if check_1288:
        for i, line in enumerate(lines, 1):
            if re.search(r"1288", line) and not re.search(r"口径|补捞|扩展|高音", line):
                out.append(f"- [FAIL] 1288 出现但无口径说明，行 {i}: {line.strip()[:80]}")
    out.append("")


def check_template_conformance(out) -> None:
    """对照官方复赛模板（hackathon-复赛作品提交模板-天池版.docx）的九章结构。"""
    out.append("## 模板格式对照（官方复赛模板九章 + 在线链接表）")
    for fname in TEMPLATE_FILES:
        lines, _ = read_file(fname)
        if lines is None:
            out.append(f"- [FAIL] {fname} 文件不存在")
            continue
        text = "\n".join(lines)
        heads = re.findall(r"^##\s*([一二三四五六七八九十]+)、(.+)$", text,
                           flags=re.M)
        nums = [h[0] for h in heads]
        titles = " ".join(h[1] for h in heads)
        missing = [s for s in TEMPLATE_SECTIONS if s not in titles]
        dup = sorted({n for n in nums if nums.count(n) > 1})
        out.append(f"- {fname}：正文章节 {len(heads)} 个")
        out.append(f"  - [{'FAIL' if missing else 'PASS'}] 模板必备章节："
                   f"{'缺 ' + '、'.join(missing) if missing else '九章齐备'}")
        out.append(f"  - [{'FAIL' if dup else 'PASS'}] 章节编号重复："
                   f"{'重复 ' + '、'.join(dup) if dup else '无'}")
        out.append(f"  - [{'PASS' if '在线链接填写表' in text else 'FAIL'}] "
                   f"在线链接填写表")
        out.append(f"  - [{'PASS' if '团队名称：更新世界的锋芒' in text else 'FAIL'}] "
                   f"团队信息已填写")
    out.append("")


def main() -> None:
    out = ["# 文档数字一致性审计", ""]
    for grp in GROUPS:
        for fname in grp["files"]:
            audit_file(fname, grp["required"], grp["forbidden"],
                       grp["check_1288"], out)
    check_template_conformance(out)
    text = "\n".join(out)
    with open(OUT_MD, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"保存 -> {OUT_MD}")
    print(text)


if __name__ == "__main__":
    main()
