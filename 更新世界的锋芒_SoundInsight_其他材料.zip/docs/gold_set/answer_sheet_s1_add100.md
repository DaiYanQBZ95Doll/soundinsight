# 人工金标 · 闸门外追加 100 条（层 S4）

> **与首轮 S1 的 100 条不重复**（按 row_index 排除）｜种子 20261003｜可复算

> **目的**：把闸门外真阳性率的 95% CI 从约 1.0%–8.5% 收窄到约 1.7%–5.3%，
> 以便判断覆盖数字能否改口。编码：**1 = 是**｜**0 = 不是**｜**2 = 无法判断**
> （与本项目其余答题卡一致；请在每条的判定位写数字，填多少收多少）

## S4-001

**原文**：This cable worked great and was delivered quickly.  This was my second order and will order again.

**翻译**：这根线缆用起来很棒，而且送货很快。这是我的第二次订购，还会再订购。

**解释**：产品：线缆｜声音：未提及｜其他：用户提到线缆使用效果很好、送货速度快，这是第二次购买，并表示会再次订购。

**判定（决策方填）**：`__0_`

## S4-002

**原文**：If you hate the thought of wasting money on something that will just end up falling off your wrist, then DO NOT BUY THIS PRODUCT. I purchased two Fitbit Flex models, one for myself and one for my husband, on April 30, 2015. I didn't buy them from Amazon, but I did buy them from an authorized retailer. By October, my husband had quit wearing his because it wouldn't sync (we figured out this was easily fixed by restarting the phone the Fitbit app was installed on). He put his up and I continued wearing mine. During this time, my Fitbit started unlatching and falling off my wrist occasionally. I would find it laying around, or would notice, then retrace my steps and find the tracker. Fast forward to January: my Fitbit tracker fell off and was lost for good. I couldn't find it anywhere. I assume some lucky soul found it and calls it their own now. I started wearing my husband's tracker at this time with no issues. Then in March, it fell off my wrist in the parking lot of my office. I didn't notice this until it was too late. Someone I work with found it and returned it to me. Unfortunately, it was ran over by a vehicle (judging by the marks on the band) and crushed. No more Fitbit. Full disclosure: I tended to play with the fastener on my first Fitbit, though I made myself not do that anymore after losing it and using the second one. I also had 9 total bands with which I used the Fitbits in  this review. I though rotating between the bands daily would keep the fastenings tighter and reduce the risk of losing my Fitbit. Not so. When I decided to contact Fitbit and ask if they might be able to help me remain a loyal customer by giving me a percentage off my next Fitbit purchase, they obliged after a string of emails back and forth, sending me an email code to be used ONLY on their website. The discount was for 25% off, which is the everyday price on many of their items on Amazon. I should have pushed for more, but I didn't realize that until I went to compare their web prices with those on Amazon. In short, I feel like I dropped $200+ on Fitbit products and all of that money was lost. Their products with a watchband type fastener seem to be better, so my only caveat is that if you choose to buy the Flex, be prepared to lose it. I am currently without a tracker and have thought about buying one, but I am gun shy when it comes to dropping another $150 on a Fitbit Charge HR (has a watchband fastener) when I know the company doesn't stand behind their products. Sorry, Fitbit.

**翻译**：如果你讨厌把钱浪费在最终会从手腕上掉下来的东西上，那么不要购买这个产品。我在2015年4月30日购买了两个Fitbit Flex型号，一个给我自己，一个给我丈夫。我不是从亚马逊买的，而是从授权零售商那里买的。到了10月，我丈夫不再戴他的了，因为它无法同步（我们发现只需重启安装了Fitbit应用的手机就能轻松解决）。他把他的收起来，我继续戴我的。在此期间，我的Fitbit开始偶尔松开并从我的手腕上掉下来。我会发现它躺在地上，或者注意到后，回溯我的脚步找到追踪器。快进到1月：我的Fitbit追踪器掉下来，永远丢失了。我到处都找不到它。我猜某个幸运的人找到了它并现在称之为自己的。这时我开始戴我丈夫的追踪器，没有问题。然后在3月，它在我办公室的停车场从我的手腕上掉下来。我直到太晚才注意到。我的一位同事找到了它并还给了我。不幸的是，它被车辆碾过（从带子上的痕迹判断）并压碎了。没有更多的Fitbit了。完全披露：我倾向于玩弄我第一个Fitbit上的扣件，尽管在丢失它并使用第二个后，我强迫自己不再这样做。我在这篇评论中总共使用了9条带子来搭配Fitbit。我以为每天轮换带子会让扣件更紧，减少丢失Fitbit的风险。并非如此。当我决定联系Fitbit，询问他们是否可以通过给我下次购买Fitbit的折扣来帮助我保持忠诚客户时，在一连串的邮件往来后，他们同意了，发给我一个只能在他们网站上使用的电子邮件代码。折扣是25% off，这是亚马逊上许多商品的日常价格。我应该争取更多，但直到我去比较他们的网站价格和亚马逊上的价格时才意识到这一点。简而言之，我觉得我在Fitbit产品上花了200多美元，所有这些钱都白费了。他们带有表带式扣件的产品似乎更好，所以我唯一的警告是，如果你选择购买Flex，准备好丢失它。我目前没有追踪器，并考虑过购买一个，但当我知道公司不支持他们的产品时，我对再花150美元购买Fitbit Charge HR（有表带扣件）感到犹豫。抱歉，Fitbit。

**解释**：产品：Fitbit Flex｜声音：未提及｜其他：用户提到产品从手腕上掉落、同步问题、扣件松动、丢失和损坏、客户服务折扣、与亚马逊价格比较、以及考虑购买Fitbit Charge HR。

**判定（决策方填）**：`_0__`

## S4-003

**原文**：Easy to get my iPhoto transferred off my iMac.<br /><br />My only 'complaint' is the green blinking light. This is only an issue b/c we have the computer in our bedroom so it freaked me out in the beginning.

**翻译**：很容易就把我的 iPhoto 从 iMac 上转移出来了。<br /><br />我唯一要说的就是那个绿色闪烁的灯。这只是个问题，因为我把电脑放在卧室里，所以一开始它吓到我了。

**解释**：产品：不确定｜声音：未提及声音｜其他：用户提到将 iPhoto 从 iMac 转移出来，以及设备上的绿色闪烁指示灯在卧室中造成困扰。

**判定（决策方填）**：`_0__`

## S4-004

**原文**：This is avery good backup camera and i would purchase again is a very clear camera

**翻译**：这是一个非常好的倒车摄像头，我会再次购买，是一个非常清晰的摄像头

**解释**：产品：倒车摄像头｜声音：未提及声音相关内容｜其他：用户提到图像清晰（very clear camera），并表示会再次购买（would purchase again）

**判定（决策方填）**：`_0__`

## S4-005

**原文**：These do NOT fit Xbox One controllers. You can put them in, but the battery chamber cover won't close. Do they work? Yes, but they don't fit properly and should not be advertised as being compatible with Xbox One Controllers.  Don't buy these if you have an Xbox One

**翻译**：这些不适合Xbox One控制器。你可以把它们放进去，但电池仓盖无法关闭。它们能用吗？能，但它们不合适，不应该被宣传为与Xbox One控制器兼容。如果你有Xbox One，不要买这些。

**解释**：产品：Xbox One控制器电池｜声音：未提及声音｜其他：电池仓盖无法关闭；不适合Xbox One控制器；兼容性宣传；建议不要购买

**判定（决策方填）**：`_0__`

## S4-006

**原文**：Bought this for mom. She likes it so far!

**翻译**：给妈妈买的。她到目前为止很喜欢！

**解释**：产品：不确定｜声音：未提及声音相关内容｜其他：购买目的（给妈妈买的）、使用反馈（她到目前为止很喜欢）

**判定（决策方填）**：`_0__`

## S4-007

**原文**：Works perfectly for adding BT to my 10-year old desktop computer. I just ordered a second because the BT driver on my company-supplied Lenovo A485 laptop is completely garbage and loses connection with my keyboard and mouse frequently. This adapter never has issues reconnecting so I’m going to plug this in and disable the Lenovo BT drivers.

**翻译**：非常适合为我的10年老台式机添加蓝牙。我刚又订购了一个，因为公司配发的联想A485笔记本上的蓝牙驱动完全是垃圾，经常与我的键盘和鼠标失去连接。这个适配器重新连接从未出过问题，所以我打算插上它并禁用联想的蓝牙驱动。

**解释**：产品：蓝牙适配器｜声音：未提及声音相关的内容｜其他：用户提到该适配器用于为老台式机添加蓝牙功能，并因联想A485笔记本的蓝牙驱动频繁断连而再次购买，计划禁用笔记本自带蓝牙驱动改用此适配器。

**判定（决策方填）**：`__0_`

## S4-008

**原文**：These are a good deal if you need a variety of colors.

**翻译**：如果你需要多种颜色，这些很划算。

**解释**：产品：不确定｜声音：未提及声音｜其他：提到颜色种类多、价格划算

**判定（决策方填）**：`__0_`

## S4-009

**原文**：Very impressed with this product.  Many useful features.  Works great.

**翻译**：对这个产品印象非常深刻。许多有用的功能。运行良好。

**解释**：产品：不确定｜声音：未提及声音相关内容｜其他：用户提到了许多有用的功能，并表示运行良好，整体印象非常深刻。

**判定（决策方填）**：`__0_`

## S4-010

**原文**：The charger is great but had to order another cord since the cord it comes with is a joke!!!! Wasn't happy with this fact either!!!!!

**翻译**：充电器很棒，但不得不另外订购一根线，因为附带的线简直是个笑话！！！！对这个事实也不满意！！！！！

**解释**：产品：充电器｜声音：未提及｜其他：用户提到充电器本身很好，但附带的线质量很差，因此另外订购了一根线，并对这一情况表示不满。

**判定（决策方填）**：`__0_`

## S4-011

**原文**：Son buenas conexiones..baja calidad pero el precio lo dise ..

**翻译**：连接不错……质量低，但价格说明了这一点……

**解释**：产品：不确定｜声音：未提及声音｜其他：提到连接（conexiones）不错，质量低（baja calidad），价格与之相符（el precio lo dise）

**判定（决策方填）**：`__0_`

## S4-012

**原文**：Works well in my Brother label maker. Feeds fine. Always have trouble getting the backs off, but that is the nature of the beast.

**翻译**：在我的Brother标签打印机上运行良好。进纸顺畅。总是很难把背胶撕下来，但这是这类东西的固有特点。

**解释**：产品：标签打印机胶带｜声音：未提及声音｜其他：提及在Brother标签打印机上运行良好、进纸顺畅、背胶难以撕下

**判定（决策方填）**：`__0_`

## S4-013

**原文**：EDIT:  Lasted seven years with about daily use.<br /><br />______________________________________________________<br /><br />IF you can find this, love it for cds and radio.

**翻译**：编辑：日常使用大约持续了七年。<br /><br />______________________________________________________<br /><br />如果你能找到这个，喜欢它用于CD和收音机。

**解释**：产品：不确定｜声音：未提及声音｜其他：日常使用持续七年；用于CD和收音机

**判定（决策方填）**：`__0_`

## S4-014

**原文**：I'm using this enclosure for an earlier-gen SATA thin profile 500GB Western Digital hard drive and getting great results. The fastest removable media I own is a SanDisk Extreme USB 3.0 flash drive. And with this enclosure, the WD hard drive is hitting read/write speeds that are almost as fast as the SanDisk Extreme. It's not nearly SATA III fast (since it's not a SATA III drive), but fast.<br /><br />I followed the recommendation of other reviewers and reformatted the hard drive to MBR and NTFS file system before using. This requires using DiskPart or Disk Management in Windows. Instructions are available on the web.<br /><br />Older hard drives with a thick profile won't fit this enclosure. If you're not sure if your hard drive is thin profile and you don't have a metric ruler handy, if it's a quarter inch or less in thickness (and has a SATA connector) it's thin profile and will fit this enclosure.<br /><br />I did not get good results testing the enclosure with a desktop computer with only USB 2.0 capability---it was very slow or not even recognized when plugged in. I don't want to blame the enclosure, because I've had similar issues with other brand enclosures and that same desktop computer. But I want to mention this in case you're thinking of buying this to use with a computer that only has USB 2.0. You might do better to get a USB 2.0 enclosure.

**翻译**：我正在使用这个硬盘盒搭配早期一代的SATA薄型500GB西部数据硬盘，效果很好。我拥有的最快的可移动媒体是SanDisk Extreme USB 3.0闪存盘。而使用这个硬盘盒，WD硬盘的读写速度几乎和SanDisk Extreme一样快。它远没有达到SATA III的速度（因为它不是SATA III硬盘），但很快。<br /><br />我遵循了其他评论者的建议，在使用前将硬盘重新格式化为MBR和NTFS文件系统。这需要使用Windows中的DiskPart或磁盘管理。网上有相关说明。<br /><br />较厚的旧硬盘无法装入这个硬盘盒。如果你不确定你的硬盘是否是薄型，并且手边没有公制尺，如果它的厚度是四分之一英寸或更薄（并且有SATA接口），那么它就是薄型，可以装入这个硬盘盒。<br /><br />我在只有USB 2.0能力的台式电脑上测试这个硬盘盒时没有得到好结果——它非常慢，甚至插入时无法识别。我不想责怪硬盘盒，因为我在其他品牌的硬盘盒和同一台台式电脑上也遇到过类似问题。但我想提一下，以防你考虑购买这个硬盘盒用于只有USB 2.0的电脑。你也许最好买一个USB 2.0的硬盘盒。

**解释**：产品：硬盘盒｜声音：未提及｜其他：读写速度几乎和SanDisk Extreme USB 3.0闪存盘一样快；建议重新格式化为MBR和NTFS；较厚的旧硬盘无法装入；在只有USB 2.0的台式电脑上测试时非常慢或无法识别，建议考虑USB 2.0硬盘盒。

**判定（决策方填）**：`__0_`

## S4-015

**原文**：Why is there reluctance to use these very useful trackers - that save so much time in locating the important things that always disappear??  Once we bridged that reluctance, we’re raving about how easy these are to use - one tends to forget about them until you need to use them.  So, we’ve won over the household and keys and cell phones are easily and quickly found.  Great choice once you get folks to use them!

**翻译**：为什么人们不愿意使用这些非常有用的追踪器——它们能节省大量时间，用来定位那些总是消失的重要物品？一旦我们克服了这种抵触情绪，我们就会对它们的使用简便赞不绝口——人们往往会忘记它们，直到需要使用时才想起来。所以，我们已经说服了全家人，钥匙和手机都能轻松快速地找到。一旦让人们开始使用，这就是个绝佳的选择！

**解释**：产品：追踪器｜声音：未提及声音相关内容｜其他：用户提到追踪器能节省时间、定位重要物品（钥匙和手机），起初存在使用抵触情绪，克服后觉得使用简便，容易忘记但需要时很有用，最终全家人都接受了。

**判定（决策方填）**：`_0__`

## S4-016

**原文**：Works great, still getting use to, but like a lot

**翻译**：效果很好，还在适应中，但很喜欢

**解释**：产品：不确定｜声音：未提及声音相关描述｜其他：用户提到使用体验良好，仍在适应，但很喜欢

**判定（决策方填）**：`__0_`

## S4-017

**原文**：I ordered this for my husband because he spends four hours a day commuting back and forth to work. I really thought I was going to have to set it up for him because I’m the technical geek but this was so easy to set up he actually did it himself. Of course I checked to see if he’s using all the wonderful features this has. It really does have an excellent view around the entire car. This gives a little peace of mind and he seems to really like it. The night vision on this is outstanding. The camera does everything, all he has to do is get in the car. This is a really great product for us.

**翻译**：我给丈夫买了这个，因为他每天上下班通勤要花四个小时。我本以为得由我来帮他设置，因为我是技术达人，但这个设置起来太简单了，他自己就搞定了。当然，我检查了他是否在用这个产品所有出色的功能。它确实能很好地看到整车周围的情况。这让人多了一点安心，他好像真的很喜欢。这个的夜视功能非常出色。摄像头什么都包办了，他只需要上车就行。这对我们来说真是个很棒的产品。

**解释**：产品：车载摄像头｜声音：未提及声音相关的内容｜其他：提到设置简单、丈夫自己完成设置、查看整车周围视野、带来安心感、夜视功能出色、摄像头自动化操作、适合通勤使用

**判定（决策方填）**：`__0_`

## S4-018

**原文**：I bought this item back in January and it has a shortage.

**翻译**：我在一月份买了这个商品，它有短缺。

**解释**：产品：不确定｜声音：未提及声音相关内容｜其他：提及购买时间为一月份，以及存在短缺问题

**判定（决策方填）**：`__0_`

## S4-019

**原文**：It actually works.........Unbelievable...... I have a cabinet filled with screen cleaners that should be called screen smear makers....!! They all suck really bad.  But this stuff......WOW.....!!<br />Just WOW......!!

**翻译**：它居然真的有用……难以置信……我有一个柜子，里面装满了屏幕清洁剂，它们应该被称为屏幕涂抹制造者……！！它们全都烂透了。但这个东西……哇……！！<br />就是哇……！！

**解释**：产品：屏幕清洁剂｜声音：未提及声音｜其他：用户提到柜子里装满了屏幕清洁剂，并说其他清洁剂效果不好，而这款产品效果很好。

**判定（决策方填）**：`_0__`

## S4-020

**原文**：I use SanDisk for all my memory card needs as they've always been very reliable. But Samsung, of course, is a fine manufacturer of electronics, so I thought I'd give them a try.<br /><br />This microSDHC card comes with an SD adapter, but I never use them as I already own a SanDisk USB adapter that plugs in any size SD card.<br />I've been using the card with my SanDisk Clip Zip (the treachery!) and haven't noticed any lag. The card is read just as quickly as SanDisks themselves, and it's always handy to have an extra card around.

**翻译**：我所有的存储卡需求都使用SanDisk，因为它们一直非常可靠。不过，三星当然是电子产品的优秀制造商，所以我想试试他们。<br /><br />这张microSDHC卡附带一个SD适配器，但我从不使用它们，因为我已经拥有一个SanDisk USB适配器，可以插入任何尺寸的SD卡。<br />我一直在我的SanDisk Clip Zip上使用这张卡（真是背叛！），没有注意到任何延迟。这张卡的读取速度和SanDisk自己的卡一样快，而且手边多一张卡总是很方便。

**解释**：产品：microSDHC存储卡｜声音：未提及声音相关内容｜其他：用户提到SanDisk的可靠性、三星作为电子产品制造商、附带SD适配器、已有SanDisk USB适配器、在SanDisk Clip Zip上使用无延迟、读取速度快、多一张卡方便。

**判定（决策方填）**：`__0_`

## S4-021

**原文**：Seems like a nice telescope<br /><br />I like the design and think it’s nice<br /><br />It seems comparable to other telescopes I’ve used before.  Seems like it has the standard functionality you’d expect<br /><br />I’m not a telescope expert but I think this seems nice overall

**翻译**：看起来是个不错的望远镜<br /><br />我喜欢这个设计，觉得它很好<br /><br />它似乎和我以前用过的其他望远镜差不多。似乎具备你期望的标准功能<br /><br />我不是望远镜专家，但我觉得整体上这个看起来不错

**解释**：产品：望远镜｜声音：未提及声音｜其他：设计、与其他望远镜的比较、标准功能、整体印象

**判定（决策方填）**：`_0__`

## S4-022

**原文**：I like the quality of the Anker cable products. They seem to last longer than other manufacturers products do.

**翻译**：我喜欢Anker线缆产品的质量。它们似乎比其他制造商的产品更耐用。

**解释**：产品：Anker线缆产品｜声音：未提及｜其他：用户提到Anker线缆产品的质量，认为它们比其他制造商的产品更耐用。

**判定（决策方填）**：`__0_`

## S4-023

**原文**：I bought this to replace the motherboard in my laptop this time.  I cleaned the CPU and installed in the new motherboard with this and a new fan and it's been rock solid.  No problems at all.  This stuff is the best you can get!

**翻译**：我这次买这个是为了更换笔记本电脑的主板。我用这个清洁了CPU，并把它和新风扇一起安装在新主板上，一直非常稳定。完全没问题。这东西是最好的！

**解释**：产品：散热硅脂｜声音：未提及声音相关内容｜其他：用户提到用于更换笔记本电脑主板，清洁CPU，安装新主板和新风扇，运行稳定，无问题，认为是最好的产品。

**判定（决策方填）**：`_0__`

## S4-024

**原文**：I know it's hard to get that part wrong but it was exactly what I needed and as advertised. Revived my security camera system. Good price also

**翻译**：我知道这部分很难出错，但它正是我需要的，而且与宣传一致。让我的安防摄像头系统恢复了。价格也不错。

**解释**：产品：安防摄像头系统配件｜声音：未提及声音相关内容｜其他：用户提到该产品正是所需、与宣传一致、使安防摄像头系统恢复工作，以及价格不错。

**判定（决策方填）**：`_0__`

## S4-025

**原文**：Everything you need at a fair price. What's not to like?

**翻译**：以合理的价格提供你所需的一切。有什么理由不喜欢呢？

**解释**：产品：不确定｜声音：未提及声音相关内容｜其他：价格合理，满足需求

**判定（决策方填）**：`_0__`

## S4-026

**原文**：Not very easy to install, won't stay in my ear.  Very frustrating.  Disappointed in product.

**翻译**：不太容易安装，无法留在我的耳朵里。非常令人沮丧。对产品感到失望。

**解释**：产品：不确定｜声音：未提及声音相关描述｜其他：安装困难、佩戴不稳、使用感受沮丧、对产品失望

**判定（决策方填）**：`_0__`

## S4-027

**原文**：loved them, comes with a neck piece to connect the AirPods to so you dont loose them. I ended up returning them cause of the pink I meant to order them in baby blue. but soo cute

**翻译**：很喜欢它们，附带一个颈挂配件可以把AirPods连接起来，这样就不会弄丢。我最后退货了，因为粉色——我本来想订的是淡蓝色。但真的太可爱了

**解释**：产品：AirPods配件（颈挂连接件）｜声音：未提及声音相关内容｜其他：提到附带颈挂配件可连接AirPods防止丢失；因颜色（粉色而非想要的淡蓝色）而退货；觉得外观很可爱

**判定（决策方填）**：`_0__`

## S4-028

**原文**：[[VIDEOID:1414bb37bbf9d7082c9e2b7784fbb922]] It’s green!  Very green!  Feels like a green sheet.<br /><br />It comes with the clips you’d need to hang it from a stand.<br /><br />This background will let computer programs put different backgrounds behind you , digitally.  You could have a picture of the ocean behind you for example.<br /><br />Overall it’s nice.  Feels soft.  Looks sturdy

**翻译**：它是绿色的！非常绿！感觉像一张绿色的床单。<br /><br />它附带了你需要用来把它挂在支架上的夹子。<br /><br />这个背景可以让电脑程序在你身后以数字方式放置不同的背景。例如，你可以在身后放一张海洋的图片。<br /><br />总体来说它不错。感觉柔软。看起来结实。

**解释**：产品：绿色背景幕布｜声音：未提及声音｜其他：颜色为绿色，像床单；附带夹子用于悬挂在支架上；可用于电脑程序数字替换背景，例如海洋图片；整体感觉不错，柔软，看起来结实。

**判定（决策方填）**：`__0_`

## S4-029

**原文**：As usual brand delivered as expected for an excellent price.  Trouble free & easy programming.

**翻译**：一如既往，该品牌以极优惠的价格如预期般交付。无故障且编程简单。

**解释**：产品：不确定｜声音：未提及声音相关内容｜其他：提及品牌、价格、编程便利性、无故障使用

**判定（决策方填）**：`__0_`

## S4-030

**原文**：I thought this would be great, nice and easy, because I have a camera that holds exactly the same: 1GB, Olympus.<br /><br />When ever I put the flash into my PC it wigs out, says error, and its not able to recover anything. I tested it out first with a few pictures i didnt actually care about. It ended up wiping them all. Glad I thought ahead!<br /><br />It also said that I needed to program the product before use. I followed the only two steps, (no brainer, click &#34;yes&#34; and &#34;ok&#34;) and there were issues with that as well, &#34;error&#34; messages again. Because the steps were so easy I am sure its not human error.<br /><br />Save your money, it's a piece of junk.

**翻译**：我以为这会很棒，又简单又方便，因为我有一台容量完全相同的相机：1GB，奥林巴斯。<br /><br />每当我将闪存插入我的电脑时，它就会出问题，显示错误，并且无法恢复任何东西。我先用一些我实际上并不在意的照片进行了测试。结果它把它们全部清除了。幸好我提前想到了！<br /><br />它还说我需要在使用前对产品进行编程。我按照仅有的两个步骤操作（很简单，点击“是”和“确定”），但这也出现了问题，再次出现“错误”信息。因为这些步骤太简单了，我确信这不是人为错误。<br /><br />省下你的钱吧，这就是个垃圾。

**解释**：产品：闪存/存储卡｜声音：未提及声音相关内容｜其他：用户提到将闪存插入电脑时出现错误、无法恢复数据、清除了照片；还提到需要编程产品，按照步骤操作后出现错误信息；最后建议省钱，称其为垃圾。

**判定（决策方填）**：`__0_`

## S4-031

**原文**：Laptop works great. Wife loves it. Didn't take long to transfer files from her broken laptop over.

**翻译**：笔记本电脑运行良好。妻子很喜欢它。从她坏掉的笔记本电脑传输文件没花多长时间。

**解释**：产品：笔记本电脑｜声音：未提及｜其他：运行良好；妻子很喜欢；从坏掉的笔记本电脑传输文件很快

**判定（决策方填）**：`__0_`

## S4-032

**原文**：My new cellphone was the first item I ever purchased that didn't come with a power block at all, just a USB to USB-C cable. Since then, every device I have gotten that recharges only comes with the cable, and no power block. This power hub is perfect for all those gadgets and the lack of USB ports my computer has. It has two for speakers, mouse, various dongles, and printer. This hub has expanded computer's capacity several fold. It seems to work just the way I hoped it would. Good product.

**翻译**：我的新手机是我买过的第一件完全不带电源适配器的物品，只有一根USB转USB-C的线。从那以后，我得到的每一个需要充电的设备都只附带线缆，没有电源适配器。这个电源集线器非常适合所有这些小工具，也弥补了我电脑USB接口不足的问题。它有两个接口用于音箱、鼠标、各种转接头和打印机。这个集线器让电脑的扩展能力增加了几倍。它似乎完全按照我希望的方式工作。好产品。

**解释**：产品：USB集线器/电源集线器｜声音：未提及声音相关内容｜其他：用户提到新手机不带电源适配器、只附带USB转USB-C线缆；其他充电设备也只附带线缆；该集线器适用于各种小工具，弥补电脑USB接口不足；有两个接口用于音箱、鼠标、转接头和打印机；扩展了电脑的容量；工作符合预期；认为是好产品。

**判定（决策方填）**：`__0_`

## S4-033

**原文**：To be clear I only used this with Ni-MH batteries so I am not sure how it does with Ni-CD aka NiCad the old batteries with the memory,  It charged the NI-MH batteries very fast and completely.  This was an excellent charger and I was using some batteries I purchased from the same company a long time ago.  This is a solid company that went to great lengths to make an issue that I brought up right in the past so I decided to go to them for their charger since one of my old ones dies.  I didn't regret the decision and am very happy with the charging ability of this device.

**翻译**：需要说明的是，我只将这款产品与镍氢（Ni-MH）电池一起使用，所以我不确定它在镍镉（Ni-CD，又称NiCad，那种有记忆效应的老式电池）上的表现如何。它给镍氢电池充电非常快而且完全充满。这是一款出色的充电器，我当时用的是很久以前从同一家公司购买的一些电池。这是一家可靠的公司，过去我提出一个问题时，他们竭尽全力去解决，所以我决定在他们那里购买充电器，因为我的一台旧充电器坏了。我没有后悔这个决定，并且对这款设备的充电能力非常满意。

**解释**：产品：电池充电器｜声音：不确定｜其他：用户提到只与镍氢（Ni-MH）电池一起使用，不确定对镍镉（Ni-CD/NiCad）电池的效果；充电速度快且完全充满（charged the NI-MH batteries very fast and completely）；认为公司可靠，过去曾积极解决用户提出的问题；因旧充电器损坏而购买此款，对充电能力满意。

**判定（决策方填）**：`_0__`

## S4-034

**原文**：Extremely handy keyboard. I cut the cable and use my laptop to stream TV right to my TV, this wireless keyboard comes in handy when I'm checking email and whatnot without having to get up and go to the laptop. It's great.<br /><br />The keys are a tad smaller than a regular keyboard, there is no wrist rest so your finger might get lost (mine do every once in a while). But, overall, it works great and is very handy to use. It keeps a charge forever is seems like. I used it for almost 10 before recharging it and even then it was working fine, I just thought I should charge it.

**翻译**：非常方便的键盘。我剪断了线，用我的笔记本电脑把电视直接串流到我的电视上，这个无线键盘在我查看邮件之类的时候很方便，不用起身去笔记本电脑那里。它很棒。<br /><br />按键比普通键盘稍小一些，没有腕托，所以你的手指可能会迷失（我的偶尔会）。但总体来说，它工作得很好，用起来非常方便。它似乎能永远保持电量。我用了将近10次才充电，即使那时它工作得也很好，我只是觉得应该充电了。

**解释**：产品：无线键盘｜声音：未提及声音相关内容｜其他：用户提到键盘非常方便，用于从笔记本电脑串流电视到电视时查看邮件等；按键比普通键盘稍小；没有腕托，手指可能会迷失；整体工作良好，使用方便；电池续航持久，用了将近10次才充电，充电时仍工作正常。

**判定（决策方填）**：`__0_`

## S4-035

**原文**：I've been using mine for a month and wow, I'm impressed. A friend told me &#34;you have to break in a video card&#34;, I understand now because the performance has increased and the video got better just from using it. I have it installed on a Gigabyte 970 board and I think the performance and what it will do on an Asus 990fx board would be crazy cool. My next project...

**翻译**：我已经用了一个月，哇，我印象深刻。一个朋友告诉我“你必须磨合显卡”，我现在明白了，因为性能提升了，视频也变得更好了，仅仅是通过使用它。我把它安装在一块技嘉970主板上，我认为它的性能以及在华硕990fx主板上的表现会非常酷。我的下一个项目……

**解释**：产品：显卡｜声音：未提及声音｜其他：用户提到使用一个月后印象深刻，朋友说需要磨合显卡，性能提升，视频变好，安装在技嘉970主板上，期待在华硕990fx主板上的表现，下一个项目。

**判定（决策方填）**：`__0_`

## S4-036

**原文**：This is attached to the back of the TV stand and is super convenient. The size is great - lots of various vampire type things can plug into it and then you can shut the whole bunch off easily if you want. It was easy to attach the clips that came with it and to pop it into the clips. The cords are all up off the floor so it's easy to pop the duster back there to clean.

**翻译**：这个固定在电视柜背面，非常方便。尺寸很棒——各种吸血鬼类型的东西都可以插进去，然后如果你想的话，可以轻松地把整堆东西关掉。附带的夹子很容易安装，也很容易把它卡进夹子里。电线都离开了地板，所以很容易把掸子伸到后面去清洁。

**解释**：产品：电源插排/插座｜声音：未提及｜其他：提及了安装在电视柜背面、尺寸合适、可插入多种设备、方便一键关闭、附带夹子易于安装、电线离地便于清洁。

**判定（决策方填）**：`_0__`

## S4-037

**原文**：I love South Park and I love my little Kenny. He has never let me down yet BUT it would be very handy if there was a cord or something so I could hang him around my neck or even drape the cord out of my pocket so I remember it is there. It is just so small that I am afraid I will wash it. If it had a cord of some sort, it would be perfect!

**翻译**：我喜欢《南方公园》，也喜欢我的小肯尼。他至今从未让我失望，但如果有一根绳子或类似的东西，能让我把他挂在脖子上，或者把绳子从口袋里垂出来，这样我就记得他在那里，那会非常方便。他太小了，我怕会把他洗了。如果他有某种绳子，那就完美了！

**解释**：产品：小肯尼（南方公园角色）小物件｜声音：未提及声音｜其他：用户表达了对《南方公园》和小肯尼的喜爱，提到小肯尼从未让他失望，并希望有绳子可以挂在脖子上或从口袋垂出，担心太小会被洗掉，认为有绳子就完美了。

**判定（决策方填）**：`__0_`

## S4-038

**原文**：Still have lots to learn as far as what I can do with these but am enjoying very much in the few days that I have had these.  Got an Alexa and 3 Echos.  Keep on partying...

**翻译**：关于我可以用这些做什么，我还有很多要学，但在拥有它们的这几天里我非常享受。买了一个Alexa和3个Echo。继续派对……

**解释**：产品：Alexa和Echo智能音箱｜声音：未提及声音｜其他：用户提到还在学习设备功能，享受使用，拥有一个Alexa和三个Echo，并说继续派对。

**判定（决策方填）**：`_0__`

## S4-039

**原文**：The reason I returned this item is because I live in the country and this radio does not have an external antenna.  It has an internal antenna and would not pickup our local stations at my house.

**翻译**：我退回这件商品的原因是我住在乡下，而这台收音机没有外接天线。它只有内置天线，在我家无法接收到我们当地的电台。

**解释**：产品：收音机｜声音：用户提到该收音机只有内置天线，无法接收到当地电台（"does not have an external antenna"、"internal antenna"、"would not pickup our local stations"）。｜其他：用户提到退货原因以及居住在农村地区。

**判定（决策方填）**：`_0__`

## S4-040

**原文**：I bought this to transfer some files from old drives to a new back up.  Once the drive is in there, it is totally unremovable. and now I have this &#34;nice&#34; enclosure that has a bad drive in it and is totally unusable. Would only recommend if you never want to remove the drive.<br /><br />Also? there are no instructions online for this product.

**翻译**：我买这个是为了把一些文件从旧硬盘传输到新的备份。一旦硬盘装进去，就完全无法取出。现在我就有了这个“不错”的外壳，里面装着一块坏硬盘，完全没法用。只有当你永远不想取出硬盘时，才会推荐它。<br /><br />另外？网上没有这个产品的说明书。

**解释**：产品：硬盘外壳｜声音：未提及｜其他：用户提到硬盘装入后无法取出，导致外壳无法使用；还提到网上没有产品说明书。

**判定（决策方填）**：`__0_`

## S4-041

**原文**：Got this for my daughter to provide some protecton for the expensive Macbook Air M2.  It was very eay to install. Just snaps on. The color is translucent and really nice.  It comes in 2 parts. One snaps on the lid and one on the base.  Seems to me that all the ports are still accessable.<br /><br />I am a vine voice reviewer but I only get items that I want and I do honest reviews.  Not all my reviews are 5 star.  But this one worked as advertized.  We've been using it for several weeks and it has stayed on and is doing the job of protecting the outside of the mac.

**翻译**：给我女儿买的，用来为昂贵的MacBook Air M2提供一些保护。安装非常容易。直接扣上就行。颜色是半透明的，非常好看。它分为两部分。一部分扣在盖子上，一部分扣在底座上。在我看来，所有端口仍然可以使用。<br /><br />我是Vine Voice评论员，但我只拿我想要的东西，并且做诚实的评论。不是所有我的评论都是5星。但这个产品如广告所说那样有效。我们已经用了几个星期，它一直没掉，并且正在履行保护Mac外部的职责。

**解释**：产品：MacBook Air M2保护壳｜声音：未提及｜其他：安装容易，直接扣上；颜色半透明好看；分为两部分，分别扣在盖子和底座；所有端口仍可使用；使用几周后仍保持安装状态并保护Mac外部；评论者身份为Vine Voice评论员，只拿想要的产品并做诚实评论，不是所有评论都是5星，但此产品如广告所说有效。

**判定（决策方填）**：`_0__`

## S4-042

**原文**：Excellent, protect the projector and store it. Although the box of the Anker Nebula projector is so good that it is not necessary. I bought it because it is very beautiful and fulfills the mission better than the original box.

**翻译**：非常好，可以保护投影仪并存放它。虽然Anker Nebula投影仪的盒子已经很好，以至于并不必要。我买它是因为它非常漂亮，并且比原装盒子更好地完成了使命。

**解释**：产品：投影仪收纳盒｜声音：未提及｜其他：保护投影仪、存放、外观漂亮、比原装盒子更好

**判定（决策方填）**：`__0_`

## S4-043

**原文**：Got these for my wife for Christmas and luckily they got her before the mess up . wife loves and hate them she has to keep picking and changing the case to match her outfilt ever day . Overall just great cases well worth the money

**翻译**：给我妻子买了这些作为圣诞礼物，幸运的是在搞砸之前就送到了她手上。妻子又爱又恨它们，她每天都得挑选和更换保护壳来搭配她的衣服。总的来说，只是很棒的保护壳，非常值这个钱。

**解释**：产品：保护壳｜声音：未提及声音相关内容｜其他：作为圣诞礼物购买；妻子对产品的喜爱与更换保护壳搭配衣服的日常行为；整体评价为很棒且物有所值

**判定（决策方填）**：`__0_`

## S4-044

**原文**：I use these when I travel. Upgraded to another brand when my Thinkpad was destroyed in Israel. After many countries, then back to the US, I ended up with an old, used X201 again! They're that reliable and still fast/enough RAM. Only drawback is no SATA 3, but with an SSD HD, speeds are acceptable. Best part, you can swap out about any component and on the 9-cell batt, last an overseas flight before a charge is needed.

**翻译**：我在旅行时使用这些。当我的Thinkpad在以色列被毁后，我升级到了另一个品牌。经过许多国家，然后回到美国，我最终又用上了一台旧的、二手的X201！它们就是那么可靠，而且仍然很快/内存足够。唯一的缺点是沒有SATA 3，但配上固态硬盘，速度可以接受。最棒的是，你几乎可以更换任何组件，而且用9芯电池，在一次海外飞行中不需要充电就能撑过去。

**解释**：产品：ThinkPad X201 笔记本电脑｜声音：未提及声音相关内容｜其他：旅行使用、可靠性、速度、内存、SATA 3、固态硬盘、可更换组件、9芯电池续航

**判定（决策方填）**：`_0__`

## S4-045

**原文**：This light set comes with multiple, adjustable phone holders and a tripod. It has a remote to control the light. There is a power cable and an adjustable stand. This set is portable - everything fits in a bag with the exception of the stand. The ring is easy to assemble. To take a picture you can place a cell phone in the center of the ring (this piece is adjustable). The holder holds the device firmly/securely in place.  The light is very bright and is controlled by a touchscreen. You can easily adjust the brightness and warmness. It has warm and cool tone settings. Great quality when using for selfies or photo shoots needing background lighting. I’d recommend it.

**翻译**：这套灯组配有多个可调节的手机支架和一个三脚架。它有一个遥控器来控制灯光。有一根电源线和可调节的支架。这套设备便于携带——除了支架外，所有东西都能装进一个包里。环形灯易于组装。拍照时，你可以把手机放在环形灯的中心（这个部件是可调节的）。支架能将设备牢固/安全地固定住。灯光非常亮，通过触摸屏控制。你可以轻松调节亮度和暖度。它有暖色调和冷色调设置。用于自拍或需要背景光的拍摄时质量很好。我会推荐它。

**解释**：产品：环形灯套装｜声音：未提及声音｜其他：提及了多个可调节手机支架、三脚架、遥控器、电源线、可调节支架、便携性、易于组装、手机固定、触摸屏控制、亮度调节、暖色调和冷色调设置、自拍和摄影质量，以及推荐。

**判定（决策方填）**：`__0_`

## S4-046

**原文**：These AMAZONBASICS REPLACEMENT POWER CABLES (for PS4 and Xbox One S/X; 12ft, Black) are a good choice if you’ve lost or damaged the power cable that came with your PS4 or Xbox One console.  You get a budget-priced set of two cables (about $12 on Amazon).  The cables are standard-quality power cables, backed by an AmazonBasics limited one-year warranty, so you don’t have to wonder whether low price means inferior quality.  The AmazonBasics cables are usually in stock; and when they’re in stock, they ship right away.  The 12-foot length reaches my electrical outlet, and doesn’t add too much extra to the cable tangle behind the TV.<br /><br />My experience with the AmazonBasics line of products has been uniformly good.  I’ll always buy an AmazonBasics cable instead of a name-brand cable, because there’s no reason to pay extra for the name brand when you’re ordering plain cables.

**翻译**：这些AMAZONBASICS替换电源线（适用于PS4和Xbox One S/X；12英尺，黑色）是如果你丢失或损坏了PS4或Xbox One主机附带的电源线时的不错选择。你得到一套两根经济实惠的线缆（亚马逊上约12美元）。这些线缆是标准质量的电源线，享有AmazonBasics有限一年保修，所以你不必怀疑低价是否意味着劣质。AmazonBasics线缆通常有货；有货时，会立即发货。12英尺的长度能够到我的电源插座，并且不会给电视后面的线缆纠缠增加太多额外长度。<br /><br />我对AmazonBasics系列产品的体验一直很好。我总是会购买AmazonBasics线缆而不是名牌线缆，因为当你订购普通线缆时，没有理由为品牌多付钱。

**解释**：产品：AMAZONBASICS替换电源线（适用于PS4和Xbox One S/X；12英尺，黑色）｜声音：未提及｜其他：提及了线缆质量、价格、保修、库存和发货、长度、品牌偏好。

**判定（决策方填）**：`_0__`

## S4-047

**原文**：So far so great! Very satisfied with this product.

**翻译**：到目前为止非常好！对这款产品非常满意。

**解释**：产品：不确定｜声音：未提及声音相关的内容｜其他：用户表达了对产品的整体满意度

**判定（决策方填）**：`__0_`

## S4-048

**原文**：I bought his camera for my tech challenged parents who wanted a small easy to use camera for their vacations. There is a setting in the menu &#34;easy&#34; that they can leave and get automatically the best settings without them having to change much. There is also an easy slider botton that changes between photo, panorama and video... so far so good. The only downside is the battery life, I felt that they ran low fast. I bought a 2 pack and car charger in addition to the original items in the pack and that was perfect for them.

**翻译**：我为技术不太熟练的父母买了这台相机，他们想要一台小巧易用的相机用于度假。菜单里有一个“easy”设置，他们可以一直使用，自动获得最佳设置，无需做太多更改。还有一个简易滑动按钮，可以在照片、全景和视频之间切换……到目前为止都很好。唯一的缺点是电池续航，我觉得电量消耗得很快。除了包装里的原装配件外，我还买了一个两件装和车载充电器，这对他们来说非常完美。

**解释**：产品：相机｜声音：未提及声音相关的内容｜其他：提到了易用性（“easy”设置、简易滑动按钮）、电池续航（电量消耗快）、以及额外购买的配件（两件装电池和车载充电器）

**判定（决策方填）**：`__0_`

## S4-049

**原文**：An excellent way to transport data while working at home during these trying times

**翻译**：在这些艰难时期在家工作时传输数据的绝佳方式

**解释**：产品：不确定｜声音：未提及｜其他：在家工作、数据传输

**判定（决策方填）**：`_0__`

## S4-050

**原文**：I own two of these and I wish I didn't.  There are pretty much unless as cloud drives, they really should just be network drives.<br />The apps for iPhone and Android are really really bad.  You are unable to change any configuration remotely.  Also WD uses Java to drive some of its software, since Java has been updated, I'm unable to access the drive.  This is due to new security in Java and WD has not updated it.  Also if they did I would be unable to access any configuration remotely because I you can't access the admin programs on the drive.<br /><br />Look at QNap, they are true storage and cloud devices.  Their mobile app are fantastic and you can install different type of program on the drive, even remotely.

**翻译**：我有两个这样的设备，我真希望我没有。它们作为云盘几乎没什么用，它们其实应该只是网络驱动器。<br />iPhone和Android的应用程序真的非常非常糟糕。你无法远程更改任何配置。此外，WD使用Java来驱动它的一些软件，自从Java更新后，我就无法访问驱动器了。这是由于Java的新安全机制，而WD没有更新它。而且即使他们更新了，我也无法远程访问任何配置，因为你无法访问驱动器上的管理程序。<br /><br />看看QNap，它们是真正的存储和云设备。它们的移动应用程序非常棒，你可以在驱动器上安装不同类型的程序，甚至可以远程安装。

**解释**：产品：西部数据（WD）网络存储设备（云盘/网络驱动器）｜声音：未提及｜其他：用户提到拥有两个该设备，认为作为云盘几乎无用，应作为网络驱动器；iPhone和Android应用非常糟糕；无法远程更改配置；WD使用Java导致更新后无法访问驱动器；无法远程访问管理程序；建议考虑QNap，称其为真正的存储和云设备，移动应用出色，可远程安装程序。

**判定（决策方填）**：`_0__`

## S4-051

**原文**：I saw pwr and thought it was a power cord... It's not... I have no use for this...<br />Look at the pictures because the description is confusing

**翻译**：我看到 pwr 还以为是电源线……结果不是……这东西我完全用不上……<br />看图片吧，因为描述让人困惑

**解释**：产品：不确定｜声音：未提及声音相关内容｜其他：用户提到看到“pwr”误以为是电源线，实际不是；表示自己用不上该产品；建议查看图片，因为文字描述令人困惑

**判定（决策方填）**：`__0_`

## S4-052

**原文**：This is great! I have 3 laptops since working from home due to Shelter in Place order and I had to switch between laptops with my old Bluetooth keyboard and it was a PAIN. this keyboard allows me to connect to all 3 (max) and switch between them with a push of a button.<br /><br />It does take some time getting used to it such as typing thinking your on one laptop but you’re not (or maybe that’s user error!) ha!<br /><br />I WISH this keyboard also came with a mouse. I had to purchase one separately that also connects to all 3. That’s the only negative I have to say about it.

**翻译**：

**解释**：产品：不确定｜声音：未提及声音相关内容｜其他：

**判定（决策方填）**：`_0__`

## S4-053

**原文**：I can fit even the larger phone in there no problem and it stays on my arm even when I'm soaked in sweat. It's comfortable. I'm not getting any kind of prickly heat problems from it. I've never had the phone slip out, and if I slide a metrocard or a few dollars in along with the phone, those stay put just as well. It has never given me any trouble. It's reliable. It's well made. It's sturdy. It's exactly what I was looking for.

**翻译**：我甚至可以把更大的手机放进去，没问题，而且即使我汗流浃背，它也能固定在我的手臂上。它很舒适。我没有因此出现任何痱子问题。手机从未滑落过，如果我同时把地铁卡或几美元和手机一起塞进去，那些东西也一样不会掉出来。它从未给我带来任何麻烦。它很可靠。它做工精良。它很结实。这正是我一直在寻找的。

**解释**：产品：手机臂包｜声音：未提及声音相关内容｜其他：用户提到可容纳较大手机、运动时固定牢固、佩戴舒适、不会引起痱子、手机和地铁卡或现金不会滑落、可靠、做工精良、结实，符合预期。

**判定（决策方填）**：`_0__`

## S4-054

**原文**：Storage is defaulted at Raid 1 for 3 TB instead of 6 TB.  Need to format drive to have access to 6 TB.<br /><br />Easy to set up, easy to navigate.  Browsing for files and folders is easy.

**翻译**：存储默认设置为 RAID 1，容量为 3 TB 而不是 6 TB。需要格式化驱动器才能使用 6 TB。<br /><br />设置简单，导航方便。浏览文件和文件夹很容易。

**解释**：产品：不确定｜声音：未提及声音相关内容｜其他：存储默认 RAID 1 配置为 3 TB 而非 6 TB，需要格式化驱动器以使用 6 TB；设置简单，导航方便，浏览文件和文件夹容易。

**判定（决策方填）**：`_0__`

## S4-055

**原文**：I have used these on my phone and computers to cover the camera lens.  They work very well for that purpose and are easy to apply.  I like knowing my camera lenses are covered and the covers can be slid open for when you want to use the camera.  They stick very well and look nice.  I used to use a piece of paper taped over my camera lens but these look so much better.  I like knowing that if my camera gets hacked at least all that can be seen is black.

**翻译**：我在手机和电脑上使用这些来遮盖摄像头镜头。它们用于这个目的效果很好，而且容易贴上。我喜欢知道我的摄像头镜头被遮住了，而且当你想使用摄像头时，盖子可以滑开。它们粘得很牢，看起来也不错。我以前用一张纸贴在摄像头上，但这些看起来好多了。我喜欢知道如果我的摄像头被黑客入侵，至少能看到的就是一片黑。

**解释**：产品：摄像头镜头盖｜声音：未提及声音｜其他：用于手机和电脑遮盖摄像头镜头；容易贴上；粘得牢；外观好看；可滑动打开；替代以前用纸贴的方式；防止黑客窥视

**判定（决策方填）**：`__0_`

## S4-056

**原文**：this camera was well worth its price. easy to use, light, and great pictures. i can only recommend this camera.

**翻译**：这台相机非常物有所值。易于使用，轻便，照片很棒。我只能推荐这台相机。

**解释**：产品：相机｜声音：未提及声音｜其他：价格、易用性、重量、照片质量、推荐

**判定（决策方填）**：`__0_`

## S4-057

**原文**：So I've had this for a week and a half as I wanted to really see what it was like before reviewing. I got this kids tablet for my daughter to watch youtube on when her other tablet is dead. I do like the preloaded apps, she really likes the drawing one. The battery life is awesome. One con is that it's not so kid friendly as the case is not actually a case, it is just the tablet design and it can easily be broken if dropped and not switched out. My biggest complaint is that it really kind of runs slow, especially when on youtube, it takes a while to load even with having excellent internet speed. So in turn my daughter gets frustrated and upset and doesn't want to use it. Also the past couple days it has been disconnecting from the Internet and having trouble reconnecting when no other device in the house is experiencing issues. It is decent for the price, we got it for 42.99, but we definitely prefer our kids fire tablet over this.

**翻译**：所以我用了它一周半，因为我想在评价之前真正了解它是什么样子的。我给我女儿买了这个儿童平板，以便在她的另一个平板没电时用来看YouTube。我确实喜欢预装的应用程序，她非常喜欢那个绘画应用。电池续航很棒。一个缺点是它并不那么适合儿童，因为外壳实际上并不是外壳，它只是平板的设计，如果掉落很容易损坏，而且不能更换。我最大的不满是它运行起来确实有点慢，尤其是在YouTube上，即使网络速度极佳，加载也需要一段时间。因此，我女儿会变得沮丧和不安，不想使用它。另外，过去几天它一直从互联网断开连接，并且重新连接时遇到困难，而家里其他设备都没有这个问题。就价格而言，它还算可以，我们花了42.99美元买的，但我们绝对更喜欢我们的儿童Fire平板。

**解释**：产品：儿童平板｜声音：用户没有提及声音方面的内容。｜其他：用户提到了预装应用（喜欢绘画应用）、电池续航（很棒）、外壳设计（不是真正的外壳，容易损坏，不能更换）、运行速度（慢，尤其在YouTube上加载慢）、网络连接（过去几天断开连接，重新连接困难）、价格（42.99美元，还算可以）、与儿童Fire平板的比较（更喜欢Fire平板）。

**判定（决策方填）**：`_0__`

## S4-058

**原文**：[[VIDEOID:44376db87a1a309c0cfbf00f4db9a82e]] I like the design of these headphones.  They don’t sit in your ear but just outside it<br /><br />The nice thing is that you can hear what’s going on around you.  I prefer this for safety purposes when I am walking my dog at night.

**翻译**：我喜欢这些耳机的设计。它们不是塞在耳朵里，而是刚好在耳朵外面。<br /><br />好处是你能听到周围发生的事情。我在晚上遛狗时出于安全考虑更喜欢这样。

**解释**：产品：耳机｜声音：用户提到耳机不塞入耳内而是位于耳外（"They don’t sit in your ear but just outside it"），并且能听到周围环境的声音（"you can hear what’s going on around you"），出于安全考虑偏好这种设计（"I prefer this for safety purposes"）。｜其他：用户提到喜欢耳机的设计（"I like the design"），以及晚上遛狗时出于安全考虑的使用场景（"when I am walking my dog at night"）。

**判定（决策方填）**：`__0_`

## S4-059

**原文**：I needed one that had the larger letters and the keys are much wider.  The other keyboard I had, I was always hitting 2-3 keys at one time.  Love it.

**翻译**：我需要一个字母更大、按键更宽的键盘。我之前用的那个键盘，我总是同时按到两三个键。很喜欢它。

**解释**：产品：键盘｜声音：未提及｜其他：用户提到需要字母更大、按键更宽的键盘，之前使用的键盘容易同时按到多个键，并表示喜欢这款产品。

**判定（决策方填）**：`__0_`

## S4-060

**原文**：it worked for 6 months then stopped. Really disappointed as  it had good reviews.

**翻译**：

**解释**：产品：不确定｜声音：未提及声音相关内容｜其他：

**判定（决策方填）**：`__0_`

## S4-061

**原文**：Works very nice. Added it to my CAPSMAN setup in my home. I like having the added 5ghz capability. I am a network professional and I have been using these for some time. This is not a typical home router and requires knowledge of networks and how they work. I would not suggest this as a home solution for your average user, but if you know what JUNOS and IOS are and are comfortable with them, then give this a shot. I switched from Cisco to Mikrotik and my wallet is much happier.

**翻译**：效果非常好。我把它加入了我家里的CAPSMAN设置中。我喜欢它增加的5GHz能力。我是一名网络专业人士，使用这些设备已经有一段时间了。这不是典型的家用路由器，需要了解网络及其工作原理。我不会建议普通用户将其作为家庭解决方案，但如果你知道JUNOS和IOS是什么，并且对它们感到熟悉，那么可以试试这个。我从Cisco换到了Mikrotik，我的钱包开心多了。

**解释**：产品：Mikrotik路由器｜声音：未提及声音｜其他：用户提到将其加入CAPSMAN设置、5GHz能力、网络专业背景、需要网络知识、不适合普通家庭用户、从Cisco切换到Mikrotik节省开支。

**判定（决策方填）**：`__0_`

## S4-062

**原文**：[[VIDEOID:e465535db75375786b87fc3c5bed2bdf]] This don’t include radiator mount screws ? Seriously this is so stupid the fans are thick you can’t use standards radiator mount screws.

**翻译**：这不包括散热器安装螺丝？说真的这太蠢了，风扇很厚，你没法用标准的散热器安装螺丝。

**解释**：产品：散热器风扇｜声音：未提及声音相关内容｜其他：用户提到产品不包含散热器安装螺丝，风扇较厚，无法使用标准散热器安装螺丝。

**判定（决策方填）**：`__0_`

## S4-063

**原文**：Like it was a two pack can use to charge two things off one port

**翻译**：喜欢它，是两件装，可以用一个端口给两个东西充电

**解释**：产品：充电器｜声音：未提及｜其他：两件装；一个端口给两个设备充电

**判定（决策方填）**：`__0_`

## S4-064

**原文**：I find having two batteries very helpful.  The are easy to recharge and light enough to keep handy in my camera bag.

**翻译**：我觉得有两块电池非常有用。它们很容易充电，而且足够轻，可以方便地放在我的相机包里。

**解释**：产品：相机电池｜声音：未提及｜其他：用户提到有两块电池很有帮助，电池易于充电，重量轻，便于放在相机包中。

**判定（决策方填）**：`_0__`

## S4-065

**原文**：It's pretty good seems to hold a lot of items.

**翻译**：它相当不错，似乎能装很多东西。

**解释**：产品：不确定｜声音：未提及声音｜其他：容量大，能装很多物品

**判定（决策方填）**：`_0__`

## S4-066

**原文**：This was an effecient and simple way to buy a television.  I knew what I wanted, so it was only a matter of minutes on-line making the purchase.  The set arrived in Orlando at the earlier part of the promised delivery window, and the actual physical delivery to my home was on time.<br /><br />Less than a month after my purchase I repeated the process for a 40" model of the same set.  There is nothing like repeat business to tell a service business that they are on track.

**翻译**：这是购买电视机的一种高效且简单的方式。我知道我想要什么，所以在线购买只花了几分钟。电视机在承诺交付窗口的较早时段到达奥兰多，实际送到我家的时间也很准时。<br /><br />购买后不到一个月，我又为同一款电视的40英寸型号重复了这一过程。没有什么比回头客更能告诉服务企业他们走在正轨上了。

**解释**：产品：电视机｜声音：未提及｜其他：购买过程高效简单；在线购买耗时几分钟；电视机在承诺交付窗口的较早时段到达奥兰多；实际送货到家准时；不到一个月后再次购买同一款40英寸型号；回头客表明服务企业走在正轨上

**判定（决策方填）**：`__0_`

## S4-067

**原文**：It's a cute case, but can be a pain to use at times.  It can be really hard to plug stuff into it, and especially so if you have L-shaped connectors.  Unfortunately we have those both for charging cords and for my kid's headphones, which makes it really hard to use either.  I like the idea of the wings as supports in theory, but they are not adjustable.  So if the angle is wrong, it's wrong.  The wings hold it up really vertically, which is not an angle that usually works well for me.  I'd get a different case if I were to purchase again, but I suppose this provides protection so we will stick with it for now.  That's a lot of plastic to just throw in the landfill because it's not perfect.

**翻译**：这是个可爱的保护壳，但有时用起来很麻烦。往里面插东西可能非常困难，尤其是如果你有L形接头的话。不幸的是，我们的充电线和孩子的耳机都是这种接头，这让两者都很难使用。理论上我喜欢用侧翼作为支撑的想法，但它们不可调节。所以如果角度不对，那就是不对。侧翼把它撑得非常垂直，而这个角度通常对我来说不太好用。如果再次购买，我会选一个不同的保护壳，但我想它能提供保护，所以目前我们会继续用着。就因为不完美就把这么多塑料扔进垃圾填埋场，实在太多了。

**解释**：产品：平板电脑保护壳｜声音：未提及声音｜其他：提到插拔困难，尤其是L形接头（L-shaped connectors），充电线和耳机都受影响；侧翼支撑不可调节（not adjustable），角度过于垂直（really vertically）；考虑再次购买会选不同保护壳，但因其提供保护而继续使用；对丢弃大量塑料感到顾虑。

**判定（决策方填）**：`__0_`

## S4-068

**原文**：Tried it and I never could get rid of the glare it had didn’t work for me.

**翻译**：试过了，我一直没法消除它的眩光，对我没用。

**解释**：产品：不确定｜声音：未提及声音｜其他：提到眩光问题，以及产品对自己不适用

**判定（决策方填）**：`__0_`

## S4-069

**原文**：I tested this in a USB 3 adapter on my MacBook Air. Why would I do that? What could possibly be the point?<br /><br />Well, I couldn't persuade my son to pull his m.2 drive and test this one against it (haven't yet, anyway - next time he wants a favor bad enough to stop playing Dark Souls to as me for it, I will update with results).<br /><br />Couldn't afford a thunderbolt adapter (what is up with that). So my question became whether USB 3 is fast enough for an m.2 drive to make a difference versus a SATA SSD.<br /><br />And it is. The Nvme drive clocks in at 400-500 mbps over the SATA drive's 240 top speed. And the price of the drives plus their adapters is about equal per gigabyte.

**翻译**：我在我的MacBook Air上用一个USB 3适配器测试了这个。我为什么要那样做？那能有什么意义呢？<br /><br />嗯，我没能说服我儿子拔出他的m.2硬盘来和这个对比测试（反正还没试过——下次他想要我帮忙时，如果他能停止玩《黑暗之魂》来求我，我就会更新结果）。<br /><br />买不起雷电适配器（这是怎么回事）。所以我的问题变成了USB 3是否足够快，让m.2硬盘相比SATA SSD能有所区别。<br /><br />而答案是肯定的。NVMe硬盘的速度达到400-500 mbps，而SATA硬盘最高只有240。而且硬盘加上适配器的每GB价格大致相同。

**解释**：产品：M.2 NVMe固态硬盘及USB 3适配器｜声音：未提及声音相关内容｜其他：用户讨论了在MacBook Air上通过USB 3适配器测试M.2 NVMe硬盘，与SATA SSD进行速度对比，NVMe达到400-500 mbps而SATA最高240 mbps，并提到价格每GB大致相同，还提及未能与儿子的m.2硬盘对比测试以及买不起雷电适配器。

**判定（决策方填）**：`_0__`

## S4-070

**原文**：After my first two pair lasted me 7 years, my grandson usurped them and have lasted him another 2. Some earbuds fail to endure a week of his Autism enhanced usage.

**翻译**：在我前两副用了7年之后，我孙子把它们抢走了，又用了2年。有些耳塞连他因自闭症而增强的使用强度都撑不过一周。

**解释**：产品：耳塞｜声音：未提及｜其他：用户提到前两副耳塞使用了7年，被孙子拿走后又用了2年；并提到有些耳塞在孙子因自闭症而增强的使用强度下撑不过一周。

**判定（决策方填）**：`__0_`

## S4-071

**原文**：It holds excellent, I use it for my 32&#34; Vizio television on the wall. You just cant pull it out like others, but I don't want that anyways, I just want to adjust it up or down like in the features.

**翻译**：它固定得很好，我把它用于挂在墙上的32英寸Vizio电视。你不能像其他支架那样把它拉出来，但反正我也不想要那样，我只想按照功能说明那样上下调节。

**解释**：产品：电视壁挂支架｜声音：未提及声音相关内容｜其他：提及用于32英寸Vizio电视、壁挂安装、不能像其他支架那样拉出、可上下调节

**判定（决策方填）**：`__0_`

## S4-072

**原文**：Asurion is 1 company that stands behind &with their word. I had 4 year contract with them and they took a reasonable time to resolve my problem concerning my broken computer. I AM VERY HAPPY WITH RESULTS. I will use ASURION PROTECTION PLANS WITH ANY & ALL NEW ELECTRONICS THANK YOU ASURION.

**翻译**：Asurion是一家信守承诺并支持其承诺的公司。我与他们签订了4年合同，他们用了合理的时间解决了我关于电脑损坏的问题。我对结果非常满意。我会在任何和所有新电子产品上使用ASURION保护计划。谢谢ASURION。

**解释**：产品：电子产品保护计划｜声音：未提及｜其他：用户提到了与Asurion的4年合同、电脑损坏问题、问题解决时间、对结果的满意度，以及未来会在新电子产品上使用Asurion保护计划。

**判定（决策方填）**：`__0_`

## S4-073

**原文**：Tips are easy to install, come with a protective mesh to keep gunk from getting into the pod mesh, and conform so well to your ear canal that it makes the noise cancellation work better! It also makes the AirPods far more stable in your ear, almost customizing the fit. I bought this version for my kid, and they couldn’t believe the difference.

**翻译**：耳塞很容易安装，附带保护网，防止污垢进入耳机网罩，并且能很好地贴合耳道，使降噪效果更好！它还让 AirPods 在耳朵里更加稳固，几乎像是定制贴合。我给孩子买了这个版本，他们简直不敢相信差别这么大。

**解释**：产品：AirPods 耳塞｜声音：用户提到降噪效果更好（makes the noise cancellation work better）｜其他：安装容易（easy to install）、附带保护网（protective mesh）、防止污垢（keep gunk from getting into the pod mesh）、贴合耳道（conform so well to your ear canal）、佩戴更稳固（far more stable in your ear）、近乎定制贴合（almost customizing the fit）、给孩子购买（bought this version for my kid）、孩子感到差别很大（couldn’t believe the difference）

**判定（决策方填）**：`_0__`

## S4-074

**原文**：I am using this for my Garage Door opener, to protect from the many storms we have that will burn out electronics that are not protected.  I years past, I lost a garage door opener to a Surge.  I feel paying a small purchase price is worth the protection and inconvenience of a loss due to a lightning induced surge.

**翻译**：我正在用这个来保护我的车库门开门器，以防我们这里频繁发生的风暴损坏未受保护的电子设备。过去几年里，我因为一次电涌损坏了一个车库门开门器。我觉得花一点小钱购买这个，比因雷击引起的电涌而遭受损失和不便更值得。

**解释**：产品：电涌保护器｜声音：未提及声音相关的内容｜其他：用户提到用于车库门开门器，保护电子设备免受风暴和雷击引起的电涌损坏，并提及过去因电涌损坏过车库门开门器。

**判定（决策方填）**：`__0_`

## S4-075

**原文**：Sellers love to have you review their product quickly (and nag you!) and I don't fault them. But for a product like this it takes time to see if it will hold up. Satisfactory so far!

**翻译**：卖家喜欢让你快速评价他们的产品（还会不停催促你！），我不怪他们。但对于这样的产品，需要时间才能看出它是否耐用。到目前为止还算满意！

**解释**：产品：不确定｜声音：未提及声音相关描述｜其他：卖家催促快速评价；产品需要时间检验耐用性；目前表现令人满意

**判定（决策方填）**：`_0__`

## S4-076

**原文**：I got this to help keep the keyboard in nice condition, as it is for my daughter's 2 in 1 chromebook I got her. She loves the color, and I love that it will keep crumbs and liquids out of the electronic to make it last for years to come. Great fit, I wish it had a little more sticky to it for the 2 in 1 chromebook can be flipped backwords so that you can use it like a tablet with keyboard behind the screen if you know what I am talking about, it will probably fall off in tablet mode. That is not a complaint. Just wanted to let people know about that if it is a deciding factor. A removable glue dot may help keep it in place or rubber cement glue if that is a concern (please know I am only suggesting it and if you do use glue of any kind understand that is at your own risk and might not be removable if you use the wrong kind). I'm not concerned with that part too much, just rinse it off or gently clean mild soap and water when it is not applied on the keyboard, let it dry fully before re applying it.

**翻译**：

**解释**：产品：不确定｜声音：未提及声音相关内容｜其他：

**判定（决策方填）**：`__0_`

## S4-077

**原文**：To convert my tv to a smart one and stream shows and movie’s.

**翻译**：为了把我的电视变成智能电视，并流媒体播放节目和电影。

**解释**：产品：电视｜声音：未提及｜其他：将电视转换为智能电视；流媒体播放节目和电影

**判定（决策方填）**：`_0__`

## S4-078

**原文**：I love this and am not sure how I ever lived without it.

**翻译**：我喜欢这个，不知道以前没有它是怎么过的。

**解释**：产品：不确定｜声音：未提及声音相关描述｜其他：用户表达了对产品的喜爱和依赖

**判定（决策方填）**：`_0__`

## S4-079

**原文**：When Xfinity raised my bill $35 bucks due to equipment price increases, I decided to try Roku.  I do not like tech anything.  I can’t believe how easy they were to install/setup.

**翻译**：当Xfinity因为设备涨价把我的账单提高了35美元时，我决定试试Roku。我一点也不喜欢科技产品。我简直不敢相信它们安装/设置起来有多容易。

**解释**：产品：Roku流媒体设备｜声音：未提及｜其他：Xfinity账单上涨35美元；设备涨价；安装和设置容易

**判定（决策方填）**：`_0__`

## S4-080

**原文**：Charges as instructed but died after 15 seconds of use. Returned.

**翻译**：按说明充电，但使用15秒后就坏了。已退货。

**解释**：产品：不确定｜声音：未提及声音相关内容｜其他：充电（charges as instructed）、使用15秒后失效（died after 15 seconds of use）、退货（returned）

**判定（决策方填）**：`__0_`

## S4-081

**原文**：I bought this and got it in and one of them is made completely different it won't  even fit in the port! I have a galaxy s20 ultra. Very disappointed I hate that I have to go through  the headache of printing a label and taking it to a drop off. Hopefully  thr replacement  will work!

**翻译**：我买了这个，收到货后发现其中一个完全不一样，甚至插不进端口！我用的是Galaxy S20 Ultra。非常失望，我讨厌还得打印标签并送到投递点这种麻烦事。希望换货后的能好用！

**解释**：产品：不确定｜声音：未提及｜其他：用户提到收到的其中一个物品与预期不同，无法插入端口；提到使用的手机型号是Galaxy S20 Ultra；表达了对需要打印退货标签并送到投递点的不满；希望换货后的产品能正常使用。

**判定（决策方填）**：`_0__`

## S4-082

**原文**：Seems like a nice idea.  My friend got a similar antenna so she could watch local channels and she’s very happy with it<br /><br />I like the design overall.  Call a professional if you’re not sure how to mount it<br /><br />I think it looks nice and hopefully will install for you easy enough so you can enjoy local channels

**翻译**：看起来是个不错的主意。我朋友买了一个类似的天线，这样她就能看本地频道了，她非常满意。<br /><br />总体上我喜欢这个设计。如果你不确定如何安装，请找专业人士。<br /><br />我觉得它看起来不错，希望安装对你来说足够简单，这样你就能享受本地频道了。

**解释**：产品：天线｜声音：未提及声音相关的内容｜其他：提及了设计、安装、观看本地频道以及朋友的使用体验。

**判定（决策方填）**：`_0__`

## S4-083

**原文**：Using this on a 17" laptop. It works perfectly. It's OK that the cooling pad base is smaller than your laptop because what you're looking for is fan alignment to the heat vents on your laptop. Worth knowing this is whisper quiet. The white LED lights are good but personally I don't understand why they have them because you can't see the lights when your laptop is on top of the cooling pad - weird design decision.

**翻译**：在17英寸笔记本电脑上使用这个。它完美运行。散热垫底座比你的笔记本电脑小是可以的，因为你要找的是风扇与笔记本电脑散热孔的 alignment。值得知道的是这非常安静。白色LED灯不错，但个人不明白为什么要有它们，因为当你的笔记本电脑放在散热垫上时你看不到灯——奇怪的设计决定。

**解释**：产品：笔记本电脑散热垫｜声音：用户说它非常安静（whisper quiet）｜其他：在17英寸笔记本电脑上使用；散热垫底座比笔记本电脑小；风扇与散热孔对齐；白色LED灯；看不到灯；奇怪的设计决定

**判定（决策方填）**：`_0__`

## S4-084

**原文**：What do I expect? just that it works- and it does. I have no issues with loose connections or signal drop outs. I use this cable to extend my wifi dongle and strategically place it for a better signal and it works great. It does not seem to weaken the wifi dongle's signal. I go from no signal at the laptop to as high as full 50+ Mbps when i raise the dongle five feet above my head.<br /><br />Great price for a good-enough cable.

**翻译**：我期望什么？只是它能用——而它确实能用。我没有遇到连接松动或信号丢失的问题。我用这根线缆来延长我的WiFi适配器，并战略性地放置它以获得更好的信号，效果很好。它似乎不会削弱WiFi适配器的信号。当我把适配器举到头顶五英尺高时，从笔记本电脑上完全没有信号变成高达完整的50+ Mbps。<br /><br />价格实惠，一根足够好的线缆。

**解释**：产品：USB延长线｜声音：未提及声音相关内容｜其他：用户提到连接稳固无松动、无信号丢失，用于延长WiFi适配器以改善信号，信号强度从无到50+ Mbps，价格实惠。

**判定（决策方填）**：`__0_`

## S4-085

**原文**：Long time Apple fan but this product has definitely turned me away. The watch looks very nice and has some nice functionality but the quality is subpar. A software update cause my battery to stop updating its life about 3 months after i received it. When I originally contacted support I was told that I would have to send the watch in for repair and could potentially have to go weeks without it. I reluctantly agreed but the support agent never sent me the return box. I was frustrated and just said screw it I can deal with it. Big mistake. Fast forward a few months and my watch battery dies (as it had several times since i had no indicator of battery life). Now it wont turn on without going through hours of what seem like endless reboot loops. This persists until it finally stops booting at all. Now all it does is show an apple logo. Tech support informs me this is not something that can be repaired and my watch must be replaced. For $229. So, for a total cost of $629 I can get a functional watch that now costs $300 a year and a half after ordering it. No thanks.<br /><br />I am currently balls deep in the apple ecosystem (3 apple tvs, macbook, ipad, 2 iphones, etc) but after this debacle I have begun the process of transitioning away.  Long story short, get a fitbit charge 2.

**翻译**：作为长期的苹果粉丝，但这个产品肯定让我失望了。这款手表看起来很不错，也有一些不错的功能，但质量却低于标准。在我收到它大约3个月后，一次软件更新导致我的电池停止更新其寿命。当我最初联系支持时，我被告知必须将手表送去维修，并且可能得几周没有它。我不情愿地同意了，但支持人员从未给我寄回寄送盒。我感到沮丧，只是说算了，我可以应付。大错特错。快进几个月，我的手表电池没电了（自从我没有电池寿命指示器以来，这已经发生过好几次）。现在它无法开机，除非经历数小时看似无休止的重启循环。这种情况持续到它最终完全停止启动。现在它只显示一个苹果标志。技术支持告知我这不是可以修复的，我的手表必须更换。要229美元。所以，总花费629美元，我可以得到一个功能正常的手表，而现在在订购一年半后，它每年花费300美元。不了，谢谢。<br /><br />我目前深陷苹果生态系统（3台苹果电视、MacBook、iPad、2部iPhone等），但在这次失败之后，我已经开始过渡离开的过程。长话短说，买个Fitbit Charge 2吧。

**解释**：产品：Apple Watch｜声音：未提及｜其他：用户提到手表外观好看、功能不错，但质量低于标准；软件更新导致电池寿命显示停止更新；联系支持后被告知需送修，但支持人员未寄回寄送盒；电池多次没电，最终手表无法开机，陷入重启循环，只显示苹果标志；技术支持称无法修复，需更换，费用229美元；总成本629美元，用户认为不划算；用户拥有多个苹果设备，但已开始过渡离开苹果生态系统；建议购买Fitbit Charge 2。

**判定（决策方填）**：`__0_`

## S4-086

**原文**：This takes a real professional to install the wires don't match up. They wouldn't return it

**翻译**：这需要真正的专业人士来安装，电线对不上。他们不会退货的。

**解释**：产品：不确定｜声音：未提及声音｜其他：安装需要专业人士，电线不匹配，无法退货

**判定（决策方填）**：`_0__`

## S4-087

**原文**：the margins and tabs do not stay in place!

**翻译**：页边距和制表符无法保持在原位！

**解释**：产品：不确定｜声音：未提及声音｜其他：用户提到页边距和制表符无法保持在原位

**判定（决策方填）**：`_0__`

## S4-088

**原文**：My mom got me this kit for my birthday and I love it! It has a lot in it to set you up for success it works amazing!

**翻译**：我妈妈给我买了这套工具作为生日礼物，我很喜欢！里面有很多东西让你成功上手，效果非常好！

**解释**：产品：工具套装｜声音：未提及｜其他：生日礼物、妈妈赠送、套装内容丰富、使用效果好

**判定（决策方填）**：`__0_`

## S4-089

**原文**：If you don't want to pay an arm and a leg these are good cheap bulbs. We keep one on backup and usually go through 3 a year.

**翻译**：如果你不想花大价钱，这些是好的便宜灯泡。我们留一个作为备用，通常一年用掉3个。

**解释**：产品：灯泡｜声音：未提及｜其他：价格便宜、作为备用、每年使用约3个

**判定（决策方填）**：`__0_`

## S4-090

**原文**：I wouldn't get anything in without this boost. Very happy!!

**翻译**：没有这个助推我什么都进不去。非常开心！！

**解释**：产品：不确定｜声音：未提及声音｜其他：用户提到需要这个助推才能进入，并表达了非常开心的情绪

**判定（决策方填）**：`_0__`

## S4-091

**原文**：Much better picture than Nest and less than half price!  On board storage means no cloud fees!

**翻译**：画面比 Nest 好得多，而且价格不到一半！板载存储意味着没有云费用！

**解释**：产品：不确定｜声音：未提及声音｜其他：画面质量比 Nest 更好；价格不到一半；板载存储；没有云费用

**判定（决策方填）**：`_0__`

## S4-092

**原文**：Best purchase I've made in a long time.  I LOVE that I can charge my phone when I go to bed and it's right next to me.  The clock itself is very basic, but love the charging station.

**翻译**：很久以来我做过的最好的购买。我喜欢我可以在睡觉时给手机充电，而且它就在我旁边。时钟本身非常基础，但很喜欢这个充电站。

**解释**：产品：带充电站的时钟｜声音：未提及｜其他：用户提到可以给手机充电、充电站就在床边、时钟功能基础、喜欢充电站。

**判定（决策方填）**：`_0__`

## S4-093

**原文**：A useless "sticker". It has a clear backing that you can not take the gold peices off of; if you do, they break. The good reviews are either old or falseified, as it does NOT work for covering a phone backing. Waste of money. Also its worth mentioning that it took 2 months to arrive, which was a new low for Amazon. Total waste of money.

**翻译**：

**解释**：产品：不确定｜声音：未提及声音相关内容｜其他：

**判定（决策方填）**：`_0__`

## S4-094

**原文**：Sometimes it stops charging. Not a great connection.

**翻译**：有时它会停止充电。连接不太好。

**解释**：产品：不确定｜声音：未提及声音｜其他：充电中断，连接不佳

**判定（决策方填）**：`__0_`

## S4-095

**原文**：If you own any of the Vanguard tripod models listed as compatible and multiple cameras this set allows you to keep two of them configured for quick swap.<br /><br />The construction is precise, although these are  not magnesium alloy like Vanguard's shoes. That is not an issue for me because they have near the same feel and the same precise fit. I can say for certain that these will work with the [[ASIN:B003BQ71MA Vanguard SBH-250 Magnesium Ballhead with Sliding Quick Shoe]], with which I tested it. As for the other models I am going to take the word of the product description. They also come with a pair of allen wrenches, so in that respect these are a complete solution.<br /><br />If you own a Vanguard tripod with a compatible head these are as good as the more expensive Vanguard counterparts in my opinion.

**翻译**：如果你拥有任何列出的兼容Vanguard三脚架型号和多台相机，这套装让你可以保持其中两台配置好以便快速更换。<br /><br />做工很精确，尽管这些不像Vanguard的鞋子那样是镁合金。这对我来说不是问题，因为它们有几乎相同的手感和同样精确的贴合。我可以肯定地说，这些会与[[ASIN:B003BQ71MA Vanguard SBH-250 Magnesium Ballhead with Sliding Quick Shoe]]配合使用，我已经测试过了。至于其他型号，我将相信产品描述。它们还配有一对内六角扳手，所以在这方面它们是完整的解决方案。<br /><br />如果你拥有带有兼容云台的Vanguard三脚架，在我看来，这些和更昂贵的Vanguard对应产品一样好。

**解释**：产品：Vanguard三脚架快装板｜声音：未提及声音｜其他：用户提到兼容性、做工、材质（非镁合金）、与Vanguard SBH-250云台的测试、附带内六角扳手、与更昂贵Vanguard产品的比较。

**判定（决策方填）**：`_0__`

## S4-096

**原文**：I use air for my keyboards and my records. This is going to save me so much money that I would have spent on canned duster. I didn't think it would be powerful enough, but I was wrong this is exactly what I needed. Hopefully it survives menu recharges.

**翻译**：我用空气来清洁我的键盘和唱片。这将为我省下很多原本要花在罐装除尘器上的钱。我原以为它的动力不够强，但我错了，这正是我需要的。希望它能经受住多次充电。

**解释**：产品：电动空气除尘器｜声音：用户没有提及声音。｜其他：用户提到用它清洁键盘和唱片，能省下买罐装除尘器的钱，原本担心动力不足但发现足够，并希望它能经受多次充电。

**判定（决策方填）**：`_0__`

## S4-097

**原文**：I have a couple of vertical mice that I use with my various computer systems, and they really do help with wrist fatigue and pressure. I also have a very nice Logitech MX Ergo trackball which is my go-to device for all of my systems. With Logitech releasing this vertical mouse, I was very optimistic that I would have the perfect solution. I was sorely disappointed. This is the worst Logitech device I have used and I can’t recommend it.<br /><br />I’ll start with the good aspects of it, and then I will get into what isn’t so good.<br /><br />This device can be connected via wireless USB or by Bluetooth. This is handy for when you want to use multiple systems and want to connect to them, in different ways. If you already have another wireless Logitech device, it can connect to the receiver for that device, reducing the number of wireless ports required. It connects well through either method and I have been able to move it between systems just with the press of the connection button on top.<br /><br />In operation, it seems to work well as a pointing device. I will say that if you are not used to working with a vertical mouse there is a learning curve that is involved and you will be very frustrated while you make the adjustment. The movement isn’t hard – it’s working with the buttons which even though are worked with the same fingers they feel unnatural at first. This is a problem with all vertical mice, not just this one.<br /><br />It is rechargeable, meaning no more batteries, and it holds a charge for a good while. I like mice and keyboards that don’t need batteries as in the very long term it saves money. (Logitech has a solar keyboard that is phenomenal and never needs to be plugged in at all – great device.)<br /><br />I have three main issues with this vertical mouse. The first is the build quality. It feels very lightweight and cheap, and I would call it fragile. It is supposed to be light and maneuverable so it’s easy to use, but it’s so much so that it has a very cheap feel to it that is unsettling. Second, this is a HUGE mouse which for me is great but for most people is unworkable. It fits my hand very well, but I have hands like a gorilla. My wife tried it and found it to be completely unusable because she couldn’t work the buttons well at all due to the size. Finally, this is a very expensive peripheral compared to other vertical mice I have used that I actually prefer. This vertical mouse presently sells here for about $100. I have one that cost around $25 at the time I bought it, feels more solid and is easier to use. My wife and I compared the Logitech vertical mouse with my cheaper one, and we both agreed that the less expensive one was easier to handle and worked just as well. The only thing I lose with the cheaper mouse is Bluetooth connectivity, which in my case is not a deal breaker.<br /><br />I wish I could rate this mouse more highly but I just can’t. It’s expensive, feels cheap and just isn’t made to fit smaller hands (and usually, it’s a challenge finding mice for larger hands). It’s worth consideration if you need a mouse that can be easily transitioned between wireless and Bluetooth, but if you just need to use it with one system I’d recommend researching other options before making a purchase.

**翻译**：我有几个垂直鼠标，用于我的各种计算机系统，它们确实有助于缓解手腕疲劳和压力。我还有一个非常好的罗技 MX Ergo 轨迹球，它是我所有系统的首选设备。随着罗技推出这款垂直鼠标，我非常乐观地认为我会拥有完美的解决方案。我非常失望。这是我用过的最差的罗技设备，我不能推荐它。<br /><br />我将从它的优点开始，然后我会谈到不太好的地方。<br /><br />这款设备可以通过无线 USB 或蓝牙连接。当你想使用多个系统并想以不同方式连接它们时，这很方便。如果你已经有另一个罗技无线设备，它可以连接到该设备的接收器，减少所需的无线端口数量。它通过任一方法都能很好地连接，我只需按下顶部的连接按钮就能在系统之间移动它。<br /><br />在操作中，它似乎作为指点设备工作良好。我要说的是，如果你不习惯使用垂直鼠标，会有一个学习曲线，你在调整过程中会非常沮丧。移动并不难——难的是使用按钮，即使是用同样的手指操作，一开始也感觉不自然。这是所有垂直鼠标的问题，不仅仅是这个。<br /><br />它是可充电的，意味着不再需要电池，而且充电后可以使用很长时间。我喜欢不需要电池的鼠标和键盘，因为从长远来看可以省钱。（罗技有一款太阳能键盘非常出色，完全不需要插电——很棒的设备。）<br /><br />我对这款垂直鼠标有三个主要问题。首先是做工质量。它感觉非常轻且廉价，我会说它很脆弱。它本应轻便灵活以便于使用，但它太轻了，给人一种非常廉价的感觉，令人不安。其次，这是一个巨大的鼠标，对我来说很好，但对大多数人来说不可行。它非常适合我的手，但我的手像大猩猩一样大。我妻子试了试，发现完全无法使用，因为由于尺寸问题，她根本无法很好地操作按钮。最后，与我实际更喜欢用过的其他垂直鼠标相比，这是一个非常昂贵的外设。这款垂直鼠标目前在这里售价约 100 美元。我有一个购买时大约 25 美元的，感觉更坚固，更容易使用。我和妻子将罗技垂直鼠标与我更便宜的鼠标进行了比较，我们都同意较便宜的那个更容易操作，工作效果也一样好。我用更便宜的鼠标唯一失去的是蓝牙连接，就我而言，这不是一个决定性因素。<br /><br />我希望我能给这款鼠标更高的评价，但我不能。它很贵，感觉廉价，而且不适合较小的手（一个

**解释**：产品：罗技垂直鼠标｜声音：未提及声音相关内容｜其他：连接方式（无线 USB 或蓝牙）、可充电、做工质量（轻、廉价、脆弱）、尺寸（巨大）、价格（约 100 美元）、与其他垂直鼠标的比较、手腕疲劳缓解、学习曲线、按钮操作

**判定（决策方填）**：`__0_`

## S4-098

**原文**：Thanks works as needed. And good value 2 for 4$.

**翻译**：谢谢，按需工作。而且性价比高，2个4美元。

**解释**：产品：不确定｜声音：未提及声音｜其他：价格、性价比、功能正常

**判定（决策方填）**：`__0_`

## S4-099

**原文**：Easily mounts on flat screens. Picture quality is awesome. I use it several times a week. Would recommend it highly.

**翻译**：容易安装在平面屏幕上。画质很棒。我每周使用几次。会强烈推荐。

**解释**：产品：不确定｜声音：未提及声音｜其他：提及安装、画质、使用频率和推荐

**判定（决策方填）**：`_0__`

## S4-100

**原文**：Well so far.very happy with my Kindle. This is my 5th one. Not because of something being wrong with them. Each new version is better than last one. I am 83 and the Kindle  is so perfect for me.

**翻译**：到目前为止很好。对我的Kindle非常满意。这是我的第5个。不是因为它们有什么问题。每个新版本都比上一个更好。我83岁了，Kindle对我来说太完美了。

**解释**：产品：Kindle电子书阅读器｜声音：未提及｜其他：用户表示对Kindle非常满意，这是第5个，不是因为之前的有问题，每个新版本都更好，用户83岁，认为Kindle非常适合自己。

**判定（决策方填）**：`__0_`

