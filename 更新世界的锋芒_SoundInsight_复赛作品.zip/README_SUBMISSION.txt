# SoundInsight 复赛作品提交包

本 zip 包含：

1. 更新世界的锋芒_SoundInsight_Demo.zip —— 可运行 Demo 源码包
2. 更新世界的锋芒_SoundInsight_复赛作品.pdf —— 【请手动放入最终 PDF】
3. 更新世界的锋芒_SoundInsight_演示视频.mp4 —— 【请手动放入演示视频】

请在最终提交前把 PDF 与视频文件放进本 zip 后提交。
